# Topic 08: State Management in Flutter (Provider / BLoC / InheritedNotifier)

## Definition
**State Management** is the organized process of controlling the state of an application and synchronizing that state across multiple widgets and screens.

### State Categories:
1. **Ephemeral State (Local State)**: State contained within a single widget (e.g., current tab in a BottomNavigationBar, text field input). Managed simply using `setState()`.
2. **App State (Global / Shared State)**: State shared across multiple distinct screens or widget subtrees (e.g., user authentication, shopping cart, global academic records). Managed using patterns such as **Provider**, **InheritedWidget**, **BLoC (Business Logic Component)**, or **Riverpod**.

## Pattern Demonstrated
This project demonstrates the core architectural pattern powering `Provider`:
- `ChangeNotifier`: Holds data and issues `notifyListeners()`.
- `InheritedNotifier`: Injects the notifier into the widget tree and efficiently triggers repaints only on subscribed widgets when changes occur.

## How to Run
```bash
cd 04_state_management_app
flutter run -d chrome
# or:
flutter run -d windows
```
