// Topic 8: State Management in Flutter
// Demonstrates Centralized State Management using ChangeNotifier & InheritedNotifier (Provider Architecture)

import 'package:flutter/material.dart';

void main() {
  runApp(const StateManagementMasterApp());
}

// ====================================================
// 1. STATE MODEL: Centralized State using ChangeNotifier
// ====================================================
class StudentSubject {
  final String title;
  int marks;

  StudentSubject(this.title, this.marks);
}

class AcademicStateManager extends ChangeNotifier {
  final List<StudentSubject> _subjects = [
    StudentSubject('CS-13: Flutter App Dev', 85),
    StudentSubject('CS-14: Node.js & Express', 78),
    StudentSubject('CS-15: Angular Framework', 82),
  ];

  List<StudentSubject> get subjects => List.unmodifiable(_subjects);

  double get averageMarks {
    if (_subjects.isEmpty) return 0.0;
    final total = _subjects.fold<int>(0, (sum, item) => sum + item.marks);
    return total / _subjects.length;
  }

  int get passCount => _subjects.where((s) => s.marks >= 40).length;

  void updateMarks(int index, int newMarks) {
    if (index >= 0 && index < _subjects.length) {
      _subjects[index].marks = newMarks.clamp(0, 100);
      // Notify all listening widgets across the tree to rebuild!
      notifyListeners();
    }
  }

  void addSubject(String title, int marks) {
    _subjects.add(StudentSubject(title, marks.clamp(0, 100)));
    notifyListeners();
  }

  void removeSubject(int index) {
    if (index >= 0 && index < _subjects.length) {
      _subjects.removeAt(index);
      notifyListeners();
    }
  }
}

// ====================================================
// 2. INHERITED PROVIDER: Supplies state down widget tree
// ====================================================
class AcademicProvider extends InheritedNotifier<AcademicStateManager> {
  const AcademicProvider({
    super.key,
    required AcademicStateManager stateManager,
    required super.child,
  }) : super(notifier: stateManager);

  // Helper method to obtain state anywhere in tree (like Provider.of<T>(context))
  static AcademicStateManager of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<AcademicProvider>()!.notifier!;
  }
}

// ====================================================
// 3. ROOT APPLICATION
// ====================================================
class StateManagementMasterApp extends StatefulWidget {
  const StateManagementMasterApp({super.key});

  @override
  State<StateManagementMasterApp> createState() => _StateManagementMasterAppState();
}

class _StateManagementMasterAppState extends State<StateManagementMasterApp> {
  final AcademicStateManager _stateManager = AcademicStateManager();

  @override
  void dispose() {
    _stateManager.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AcademicProvider(
      stateManager: _stateManager,
      child: MaterialApp(
        title: 'Flutter State Management',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrange),
          useMaterial3: true,
        ),
        home: const AcademicDashboardScreen(),
      ),
    );
  }
}

// ====================================================
// 4. DASHBOARD SCREEN
// ====================================================
class AcademicDashboardScreen extends StatelessWidget {
  const AcademicDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final state = AcademicProvider.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('State Management (ChangeNotifier)'),
        backgroundColor: Colors.deepOrange,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // SUMMARY WIDGET: Rebuilds whenever state changes
            Card(
              color: Colors.deepOrange.shade50,
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Column(
                      children: [
                        const Text('Average Score', style: TextStyle(color: Colors.grey)),
                        Text(
                          '${state.averageMarks.toStringAsFixed(1)}%',
                          style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.deepOrange),
                        ),
                      ],
                    ),
                    Column(
                      children: [
                        const Text('Passing Subjects', style: TextStyle(color: Colors.grey)),
                        Text(
                          '${state.passCount} / ${state.subjects.length}',
                          style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.green),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                'Adjust marks below (State updates immediately):',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            const SizedBox(height: 8),

            // SUBJECT LIST WIDGET
            Expanded(
              child: ListView.builder(
                itemCount: state.subjects.length,
                itemBuilder: (context, index) {
                  final sub = state.subjects[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    child: Padding(
                      padding: const EdgeInsets.all(12.0),
                      child: Row(
                        children: [
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(sub.title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                                Text('Marks: ${sub.marks}/100', style: TextStyle(color: sub.marks >= 40 ? Colors.green : Colors.red)),
                              ],
                            ),
                          ),
                          IconButton(
                            icon: const Icon(Icons.remove_circle_outline, color: Colors.red),
                            onPressed: () => state.updateMarks(index, sub.marks - 5),
                          ),
                          IconButton(
                            icon: const Icon(Icons.add_circle_outline, color: Colors.green),
                            onPressed: () => state.updateMarks(index, sub.marks + 5),
                          ),
                          IconButton(
                            icon: const Icon(Icons.delete_outline, color: Colors.grey),
                            onPressed: () => state.removeSubject(index),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          state.addSubject('New Elective Subject', 75);
        },
        icon: const Icon(Icons.add),
        label: const Text('Add Subject'),
      ),
    );
  }
}
