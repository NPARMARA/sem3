# Topic 01, 03, 04, 05: Flutter Widgets & State Management

## Definitions

1. **Flutter**: Google's open-source multi-platform UI toolkit that compiles natively to ARM machine code or JavaScript from a single Dart codebase.
2. **Widget**: The foundational building block of Flutter applications. Everything in Flutter is a widget — from structural layouts (`Scaffold`, `Column`, `Row`) to visual elements (`Text`, `Icon`, `Image`) and stylings (`Padding`, `Theme`).
3. **StatelessWidget**: An immutable widget that does not store any internal state that changes across its lifetime. Its configuration is set via constructor arguments and rendered via `build()`.
4. **StatefulWidget**: A widget that tracks mutable dynamic state. It consists of two classes:
   - The `StatefulWidget` configuration class.
   - The associated `State<T>` class that holds the data and calls `setState(() { ... })` to inform the framework to repaint the UI.

## How to Run
```bash
cd 02_flutter_widgets_app
flutter run -d chrome
# Or to run on Windows desktop:
flutter run -d windows
```
