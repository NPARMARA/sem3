// Topic 9: REST API Integration in Flutter
// Demonstrates http networking, jsonDecode, Model class deserialization, and FutureBuilder UI handling

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

void main() {
  runApp(const RestApiMasterApp());
}

// ====================================================
// 1. DATA MODEL (JSON Deserialization)
// ====================================================
class StudentUser {
  final int id;
  final String name;
  final String email;
  final String city;
  final String company;

  StudentUser({
    required this.id,
    required this.name,
    required this.email,
    required this.city,
    required this.company,
  });

  // Factory constructor to deserialize JSON map into typed Dart object
  factory StudentUser.fromJson(Map<String, dynamic> json) {
    return StudentUser(
      id: json['id'] ?? 0,
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      city: json['address'] != null ? json['address']['city'] ?? '' : '',
      company: json['company'] != null ? json['company']['name'] ?? '' : '',
    );
  }
}

// ====================================================
// 2. ROOT APPLICATION
// ====================================================
class RestApiMasterApp extends StatelessWidget {
  const RestApiMasterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'REST API & JSON Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: const StudentApiListScreen(),
    );
  }
}

// ====================================================
// 3. API SCREEN WITH FUTUREBUILDER
// ====================================================
class StudentApiListScreen extends StatefulWidget {
  const StudentApiListScreen({super.key});

  @override
  State<StudentApiListScreen> createState() => _StudentApiListScreenState();
}

class _StudentApiListScreenState extends State<StudentApiListScreen> {
  late Future<List<StudentUser>> _futureUsers;

  @override
  void initState() {
    super.initState();
    _futureUsers = fetchUsersFromApi();
  }

  // Asynchronous REST API call with jsonDecode
  Future<List<StudentUser>> fetchUsersFromApi() async {
    const apiUrl = 'https://jsonplaceholder.typicode.com/users';

    try {
      final response = await http.get(Uri.parse(apiUrl)).timeout(
        const Duration(seconds: 10),
      );

      if (response.statusCode == 200) {
        // Parse raw JSON string into dynamic List
        final List<dynamic> jsonList = jsonDecode(response.body);
        // Map each JSON object to our typed Model
        return jsonList.map((item) => StudentUser.fromJson(item)).toList();
      } else {
        throw Exception('Server responded with HTTP status ${response.statusCode}');
      }
    } catch (e) {
      // In case of offline testing, return mock data gracefully
      return [
        StudentUser(id: 1, name: 'Rahul Sharma (Offline Cached)', email: 'rahul@mscit.edu', city: 'Rajkot', company: 'Saurashtra Uni'),
        StudentUser(id: 2, name: 'Pooja Varma (Offline Cached)', email: 'pooja@mscit.edu', city: 'Ahmedabad', company: 'IT Dept'),
      ];
    }
  }

  void _refreshData() {
    setState(() {
      _futureUsers = fetchUsersFromApi();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('REST API (FutureBuilder)'),
        backgroundColor: Colors.blue,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshData,
            tooltip: 'Reload API Data',
          ),
        ],
      ),
      // TOPIC 9: FutureBuilder widget handles asynchronous state transitions
      body: FutureBuilder<List<StudentUser>>(
        future: _futureUsers,
        builder: (context, snapshot) {
          // 1. ConnectionState.waiting -> Show Progress Indicator
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CircularProgressIndicator(),
                  SizedBox(height: 16),
                  Text('Fetching data asynchronously over HTTP...'),
                ],
              ),
            );
          }

          // 2. snapshot.hasError -> Show Error UI
          if (snapshot.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.error_outline, color: Colors.red, size: 48),
                    const SizedBox(height: 12),
                    Text('API Error: ${snapshot.error}', textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    ElevatedButton(onPressed: _refreshData, child: const Text('Retry')),
                  ],
                ),
              ),
            );
          }

          // 3. snapshot.hasData -> Render Data List
          if (snapshot.hasData && snapshot.data!.isNotEmpty) {
            final users = snapshot.data!;
            return ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: users.length,
              itemBuilder: (context, index) {
                final user = users[index];
                return Card(
                  margin: const EdgeInsets.only(bottom: 10),
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: Colors.blue.shade100,
                      foregroundColor: Colors.blue.shade800,
                      child: Text('${user.id}'),
                    ),
                    title: Text(user.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text('${user.email}\nCity: ${user.city} | ${user.company}'),
                    isThreeLine: true,
                  ),
                );
              },
            );
          }

          return const Center(child: Text('No data records found.'));
        },
      ),
    );
  }
}
