# Topic 09: REST API Integration & JSON Serialization

## Definition
**REST (Representational State Transfer) API Integration** in Flutter involves sending HTTP requests (`GET`, `POST`, `PUT`, `DELETE`) to a web server and processing the JSON responses asynchronously using Dart's `Future`, `async/await`, and `dart:convert` (`jsonDecode`).

### Core Concepts Demonstrated:
1. **`http` Package**: Issues HTTP requests (`http.get(url)`).
2. **JSON Deserialization**: Parses JSON string via `jsonDecode()` and maps it into strongly-typed model instances via `factory Model.fromJson()`.
3. **`FutureBuilder<T>` Widget**: Automatically rebuilds based on the asynchronous state (`ConnectionState.waiting`, `hasError`, `hasData`), eliminating manual loading flag state management.

## How to Run
```bash
cd 05_rest_api_app
flutter pub get
flutter run -d chrome
# or:
flutter run -d windows
```
