// Topic 10: SQLite Database (sqflite) in Flutter
// Demonstrates local relational database storage, schema definition, and full CRUD operations

import 'package:flutter/material.dart';

void main() {
  runApp(const SqliteCrudMasterApp());
}

// ====================================================
// 1. DATA MODEL (Student Record for SQLite)
// ====================================================
class StudentDbRecord {
  final int? id;
  final String name;
  final String course;
  final int marks;

  StudentDbRecord({
    this.id,
    required this.name,
    required this.course,
    required this.marks,
  });

  // Convert model object to SQL Map for insertion/update
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'course': course,
      'marks': marks,
    };
  }

  // Construct model from SQL query result row Map
  factory StudentDbRecord.fromMap(Map<String, dynamic> map) {
    return StudentDbRecord(
      id: map['id'],
      name: map['name'] ?? '',
      course: map['course'] ?? '',
      marks: map['marks'] ?? 0,
    );
  }
}

// ====================================================
// 2. SQLITE DATABASE SERVICE INTERFACE / SIMULATION
// Demonstrates SQL DDL & DML statements for exams
// ====================================================
class StudentDatabaseService {
  // Simulates internal SQLite table storage with standard SQL contracts
  final List<StudentDbRecord> _localDbTable = [
    StudentDbRecord(id: 1, name: 'Rahul Sharma', course: 'M.Sc. IT & CA', marks: 88),
    StudentDbRecord(id: 2, name: 'Priya Patel', course: 'M.Sc. IT & CA', marks: 92),
    StudentDbRecord(id: 3, name: 'Kishan Dave', course: 'M.Sc. IT & CA', marks: 65),
  ];
  int _autoIncrementId = 4;

  // DDL: CREATE TABLE students (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, course TEXT, marks INTEGER)

  // 1. SELECT (Read all records)
  Future<List<StudentDbRecord>> getAllStudents() async {
    await Future.delayed(const Duration(milliseconds: 200));
    return List.from(_localDbTable);
  }

  // 2. INSERT (Create record)
  Future<int> insertStudent(StudentDbRecord student) async {
    await Future.delayed(const Duration(milliseconds: 200));
    final recordWithId = StudentDbRecord(
      id: _autoIncrementId++,
      name: student.name,
      course: student.course,
      marks: student.marks,
    );
    _localDbTable.add(recordWithId);
    return recordWithId.id!;
  }

  // 3. UPDATE (Modify record)
  Future<int> updateStudent(StudentDbRecord student) async {
    await Future.delayed(const Duration(milliseconds: 200));
    final index = _localDbTable.indexWhere((s) => s.id == student.id);
    if (index != -1) {
      _localDbTable[index] = student;
      return 1;
    }
    return 0;
  }

  // 4. DELETE (Remove record)
  Future<int> deleteStudent(int id) async {
    await Future.delayed(const Duration(milliseconds: 200));
    _localDbTable.removeWhere((s) => s.id == id);
    return 1;
  }
}

// ====================================================
// 3. ROOT APPLICATION
// ====================================================
class SqliteCrudMasterApp extends StatelessWidget {
  const SqliteCrudMasterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter SQLite CRUD',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.brown),
        useMaterial3: true,
      ),
      home: const SqliteHomeScreen(),
    );
  }
}

// ====================================================
// 4. CRUD USER INTERFACE SCREEN
// ====================================================
class SqliteHomeScreen extends StatefulWidget {
  const SqliteHomeScreen({super.key});

  @override
  State<SqliteHomeScreen> createState() => _SqliteHomeScreenState();
}

class _SqliteHomeScreenState extends State<SqliteHomeScreen> {
  final StudentDatabaseService _dbService = StudentDatabaseService();
  List<StudentDbRecord> _students = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _refreshStudentList();
  }

  Future<void> _refreshStudentList() async {
    setState(() => _isLoading = true);
    final data = await _dbService.getAllStudents();
    setState(() {
      _students = data;
      _isLoading = false;
    });
  }

  void _showStudentDialog({StudentDbRecord? studentToEdit}) {
    final nameController = TextEditingController(text: studentToEdit?.name ?? '');
    final courseController = TextEditingController(text: studentToEdit?.course ?? 'M.Sc. IT & CA');
    final marksController = TextEditingController(text: studentToEdit?.marks.toString() ?? '');

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(studentToEdit == null ? 'Add Student (SQLite INSERT)' : 'Edit Student (SQLite UPDATE)'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'Student Name'),
            ),
            TextField(
              controller: courseController,
              decoration: const InputDecoration(labelText: 'Course'),
            ),
            TextField(
              controller: marksController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'Internal Marks'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () async {
              final name = nameController.text.trim();
              final course = courseController.text.trim();
              final marks = int.tryParse(marksController.text.trim()) ?? 0;

              if (name.isNotEmpty) {
                if (studentToEdit == null) {
                  // SQL INSERT
                  await _dbService.insertStudent(StudentDbRecord(
                    name: name,
                    course: course,
                    marks: marks,
                  ));
                } else {
                  // SQL UPDATE
                  await _dbService.updateStudent(StudentDbRecord(
                    id: studentToEdit.id,
                    name: name,
                    course: course,
                    marks: marks,
                  ));
                }
                Navigator.pop(ctx);
                _refreshStudentList();
              }
            },
            child: Text(studentToEdit == null ? 'Insert' : 'Update'),
          ),
        ],
      ),
    );
  }

  Future<void> _confirmDelete(int id, String name) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Record (SQL DELETE)'),
        content: Text('Delete student "$name" from local SQLite table?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red, foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _dbService.deleteStudent(id);
      _refreshStudentList();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SQLite Database CRUD'),
        backgroundColor: Colors.brown,
        foregroundColor: Colors.white,
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _students.isEmpty
              ? const Center(child: Text('No SQLite records found. Click + to insert.'))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: _students.length,
                  itemBuilder: (context, index) {
                    final student = _students[index];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Colors.brown.shade100,
                          foregroundColor: Colors.brown.shade800,
                          child: Text('${student.id}'),
                        ),
                        title: Text(student.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text('${student.course} | Marks: ${student.marks}/100'),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              icon: const Icon(Icons.edit, color: Colors.blue),
                              onPressed: () => _showStudentDialog(studentToEdit: student),
                            ),
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: () => _confirmDelete(student.id!, student.name),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: Colors.brown,
        foregroundColor: Colors.white,
        onPressed: () => _showStudentDialog(),
        icon: const Icon(Icons.add),
        label: const Text('Insert Student'),
      ),
    );
  }
}
