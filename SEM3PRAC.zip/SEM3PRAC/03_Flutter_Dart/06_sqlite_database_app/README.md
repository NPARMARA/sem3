# Topic 10: SQLite (`sqflite`) Local Database in Flutter

## Definition
**SQLite (`sqflite`)** is a lightweight, zero-configuration, transactional relational database engine used in Flutter applications to store, query, modify, and delete structured tabular data offline on mobile devices.

### Standard CRUD SQL Operations Demonstrated:
1. **CREATE TABLE (DDL)**:
   ```sql
   CREATE TABLE students(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, course TEXT, marks INTEGER);
   ```
2. **INSERT (Create)**:
   ```dart
   await db.insert('students', student.toMap());
   ```
3. **QUERY / SELECT (Read)**:
   ```dart
   final List<Map<String, dynamic>> maps = await db.query('students');
   ```
4. **UPDATE (Modify)**:
   ```dart
   await db.update('students', student.toMap(), where: 'id = ?', whereArgs: [student.id]);
   ```
5. **DELETE (Remove)**:
   ```dart
   await db.delete('students', where: 'id = ?', whereArgs: [id]);
   ```

## How to Run
```bash
cd 06_sqlite_database_app
flutter pub get
flutter run -d chrome
# or:
flutter run -d windows
```
