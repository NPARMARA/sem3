# 🟠 03_Flutter_Dart: Complete Practical Projects

This folder contains dedicated, runnable projects covering all 10 Flutter & Dart definitions and core syllabus topics for **M.Sc. (IT & CA) Semester 3 (CS-13 & CS-16 Practical)**:

---

## Index of Projects & Syllabus Topics

| Sub-Folder | Syllabus Topics Covered | Key Concepts Demonstrated | Run Command |
| :--- | :--- | :--- | :--- |
| **`01_dart_fundamentals/`** | 2. Dart Language | Strong typing, Sound Null Safety (`?`, `??`), OOP (Inheritance, Abstract classes), Async/Await (`Future`) | `dart run bin/main.dart` |
| **`02_flutter_widgets_app/`** | 1. Flutter<br>3. Widget<br>4. StatelessWidget<br>5. StatefulWidget | UI hierarchy, Scaffold, AppBar, Column, Row, Card, `setState()` dynamic rebuilds | `flutter run -d chrome` |
| **`03_navigation_routes_app/`** | 6. Hot Reload<br>7. Navigator | Hot reload VM mechanics, `Navigator.push`, `Navigator.pop`, Named routes, passing route arguments | `flutter run -d chrome` |
| **`04_state_management_app/`** | 8. State Management | Ephemeral vs App State, `ChangeNotifier`, `InheritedNotifier` / Provider architecture | `flutter run -d chrome` |
| **`05_rest_api_app/`** | 9. REST API Integration | `http` package, `jsonDecode`, typed Model `.fromJson()`, `FutureBuilder<T>` async handling | `flutter run -d chrome` |
| **`06_sqlite_database_app/`** | 10. SQLite (`sqflite`) | Local relational storage, table schema, SQL CRUD (INSERT, SELECT, UPDATE, DELETE) | `flutter run -d chrome` |

---

## Execution Guide

### Running Dart Fundamentals
```bash
cd 01_dart_fundamentals
dart run bin/main.dart
```

### Running Any Flutter Sub-Project
```bash
cd 02_flutter_widgets_app
flutter run -d chrome   # Launches in Google Chrome
# or run natively on Windows desktop:
flutter run -d windows
```
