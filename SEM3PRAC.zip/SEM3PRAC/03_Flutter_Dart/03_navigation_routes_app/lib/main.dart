// Topics 6 & 7: Hot Reload & Flutter Navigator Route Management
// Demonstrates Navigator.push, Navigator.pop, Named Routes, Route Arguments, and Returning Data

import 'package:flutter/material.dart';

void main() {
  runApp(const NavigationMasterApp());
}

class NavigationMasterApp extends StatelessWidget {
  const NavigationMasterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Navigation & Routes',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
      ),
      // Initial route
      initialRoute: '/',
      // Named Routes Registration Table
      routes: {
        '/': (context) => const HomeScreen(),
        '/details': (context) => const StudentDetailsScreen(),
        '/settings': (context) => const SettingsScreen(),
      },
    );
  }
}

// ==========================================
// SCREEN 1: Home Screen (Route: '/')
// ==========================================
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  String _lastFeedback = 'None yet';

  final List<Map<String, dynamic>> _students = [
    {'roll': 101, 'name': 'Rahul Sharma', 'course': 'M.Sc. (IT & CA)', 'score': 92},
    {'roll': 102, 'name': 'Priya Patel', 'course': 'M.Sc. (IT & CA)', 'score': 84},
    {'roll': 103, 'name': 'Harsh Vora', 'course': 'M.Sc. (IT & CA)', 'score': 77},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Navigator Routes (Screen 1)'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () async {
              // TOPIC 7: Named route navigation + awaiting returned result from popped screen!
              final returnedValue = await Navigator.pushNamed(context, '/settings');
              if (returnedValue != null) {
                setState(() {
                  _lastFeedback = returnedValue.toString();
                });
              }
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.teal.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.teal.shade200),
              ),
              child: Row(
                children: [
                  const Icon(Icons.info_outline, color: Colors.teal),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text('Returned from Settings: $_lastFeedback',
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            const Text(
              'Select Student to Navigate (Navigator.push with Arguments):',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: _students.length,
                itemBuilder: (context, index) {
                  final student = _students[index];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: Colors.teal,
                        foregroundColor: Colors.white,
                        child: Text('${student['roll']}'),
                      ),
                      title: Text(student['name']),
                      subtitle: Text('${student['course']} - Score: ${student['score']}%'),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                      onTap: () {
                        // TOPIC 7: Navigator.push with arguments
                        Navigator.pushNamed(
                          context,
                          '/details',
                          arguments: student,
                        );
                      },
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==========================================
// SCREEN 2: Details Screen (Route: '/details')
// ==========================================
class StudentDetailsScreen extends StatelessWidget {
  const StudentDetailsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Extracting route arguments
    final student = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;

    return Scaffold(
      appBar: AppBar(
        title: Text('${student['name']} Details'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircleAvatar(
                radius: 40,
                backgroundColor: Colors.teal,
                child: Icon(Icons.person, size: 50, color: Colors.white),
              ),
              const SizedBox(height: 16),
              Text(student['name'], style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              Text('Roll Number: ${student['roll']}', style: const TextStyle(fontSize: 16, color: Colors.grey)),
              const SizedBox(height: 12),
              Chip(
                label: Text('Internal Marks: ${student['score']} / 100'),
                backgroundColor: Colors.teal.shade100,
              ),
              const SizedBox(height: 30),
              ElevatedButton.icon(
                onPressed: () {
                  // TOPIC 7: Navigator.pop pops screen from stack
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.arrow_back),
                label: const Text('Back to Student List (Navigator.pop)'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ==========================================
// SCREEN 3: Settings Screen (Route: '/settings')
// ==========================================
class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings (Returning Data)'),
        backgroundColor: Colors.teal,
        foregroundColor: Colors.white,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Select preferred grading mode to return to parent screen:',
              style: TextStyle(fontSize: 16),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Return result to calling Navigator.push
                Navigator.pop(context, 'Standard Percentage (0-100)');
              },
              child: const Text('Return: Standard Percentage'),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, 'Letter Grade Scale (A/B/C/F)');
              },
              child: const Text('Return: Letter Grade Scale'),
            ),
          ],
        ),
      ),
    );
  }
}
