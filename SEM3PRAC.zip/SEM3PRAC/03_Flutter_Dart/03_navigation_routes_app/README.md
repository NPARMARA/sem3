# Topic 06 & 07: Hot Reload & Flutter Navigator Routes

## Definitions

1. **Hot Reload**: A standout productivity feature of Flutter. It works by injecting updated source code files directly into the running Dart Virtual Machine (VM). The Dart VM updates class versions with the new fields and functions, and Flutter rebuilds the widget tree in milliseconds *without restarting the application or wiping in-memory state*.
2. **Navigator**: A widget that manages a stack of `Route` objects using standard LIFO (Last-In, First-Out) stack principles:
   - `Navigator.push(context, route)`: Pushes a new route onto the top of the stack, transitioning to a new screen.
   - `Navigator.pop(context, [result])`: Removes the uppermost screen from the navigation stack and optionally returns a result to the preceding screen.
   - **Named Routes**: Centralized URL-like route paths registered in `MaterialApp(routes: { ... })`.

## How to Run
```bash
cd 03_navigation_routes_app
flutter run -d chrome
# or:
flutter run -d windows
```
