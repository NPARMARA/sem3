# Topic 01 & 02: Dart Language Fundamentals

## Definition
**Dart** is a client-optimized, object-oriented, class-based programming language developed by Google. It features sound null safety, AOT (Ahead-of-Time) compilation to fast native machine code for production, and JIT (Just-in-Time) compilation for lightning-fast sub-second development with Hot Reload.

## Core Concepts Demonstrated
1. **Strong Typing & Data Types**: `int`, `double`, `String`, `bool`, `List`, `Map`.
2. **Sound Null Safety**: Nullable types (`String?`), Null-coalescing (`??`), Null-assertion (`!`).
3. **OOP Concepts**: Abstract classes, inheritance (`extends`), constructors (`super.name`), method overriding (`@override`), and getters.
4. **Asynchronous Execution**: `Future<T>`, `async`, `await`, and `Future.delayed`.

## How to Run
```bash
cd 01_dart_fundamentals
dart run bin/main.dart
```
