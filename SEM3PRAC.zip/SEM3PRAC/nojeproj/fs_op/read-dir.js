// node fs_op/read-dir.js

const fs = require('fs').promises;
const path = require('path');

async function readDir() {
  const dirPath = path.join(__dirname, 'test-folder');
  const files = await fs.readdir(dirPath);
  console.log('Files inside "test-folder":', files);
}

readDir();