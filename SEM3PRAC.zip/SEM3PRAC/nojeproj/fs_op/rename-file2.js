// node fs_op/rename-file2.js

const fs = require("fs").promises;
const path = require("path");

async function renameFile2() {
  const newPath = path.join(__dirname, "test-folder", "note.txt");
  const oldPath = path.join(__dirname, "test-folder", "renamed-note.txt");
  await fs.rename(oldPath, newPath);
  console.log('File renamed to "note.txt" successfully!');
}

renameFile2();
