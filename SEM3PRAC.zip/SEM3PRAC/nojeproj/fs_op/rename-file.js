// node fs_op/rename-file.js

const fs = require('fs').promises;
const path = require('path');

async function renameFile() {
  const oldPath = path.join(__dirname, 'test-folder', 'note.txt');
  const newPath = path.join(__dirname, 'test-folder', 'renamed-note.txt');
  await fs.rename(oldPath, newPath);
  console.log('File renamed to "renamed-note.txt" successfully!');
}

renameFile();