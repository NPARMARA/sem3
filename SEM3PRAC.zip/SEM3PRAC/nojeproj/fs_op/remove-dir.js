// node fs_op/remove-dir.js

const fs = require('fs').promises;
const path = require('path');

async function removeDir() {
  const dirPath = path.join(__dirname, 'test-folder');
  await fs.rmdir(dirPath);
  console.log('Directory "test-folder" removed successfully!');
}

removeDir();