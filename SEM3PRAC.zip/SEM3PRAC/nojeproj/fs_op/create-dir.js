// node fs_op/create-dir.js

const fs = require('fs').promises;
const path = require('path');

async function createDir() {
  const dirPath = path.join(__dirname, 'test-folder');
  await fs.mkdir(dirPath, { recursive: true });
  console.log('Directory "test-folder" created successfully!');
}

createDir();