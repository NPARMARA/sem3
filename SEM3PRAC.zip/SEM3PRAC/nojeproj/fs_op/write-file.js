// node fs_op/write-file.js

const fs = require("fs").promises;
const path = require("path");

async function writeFile() {
  const filePath = path.join(__dirname, "test-folder", "note.txt");
  await fs.writeFile(filePath, "Hello, this is the first line!\n");
  console.log('File "note.txt" written successfully!');
}

writeFile();
