// node fs_op/delete-file.js

const fs = require("fs").promises;
const path = require("path");

async function deleteFile() {
  try {
    const filePath = path.join(__dirname, "test-folder", "note.txt");
    await fs.unlink(filePath);
    console.log('File "note.txt" deleted successfully!');
  } catch (e) {
    try {
      const filePath = path.join(__dirname, "test-folder", "renamed-note.txt");
      await fs.unlink(filePath);
      console.log('File "renamed-note.txt" deleted successfully!');
    } catch (e) {
      throw e;
    }
  }
}

deleteFile();
