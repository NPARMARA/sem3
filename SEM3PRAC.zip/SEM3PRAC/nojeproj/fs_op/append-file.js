// node fs_op/append-file.js

const fs = require('fs').promises;
const path = require('path');

async function appendFile() {
  const filePath = path.join(__dirname, 'test-folder', 'note.txt');
  await fs.appendFile(filePath, 'This is an appended second line.\n');
  console.log('Data appended to "note.txt" successfully!');
}

appendFile();