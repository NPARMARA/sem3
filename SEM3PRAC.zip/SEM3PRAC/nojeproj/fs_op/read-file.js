// node fs_op/read-file.js

const fs = require('fs').promises;
const path = require('path');

async function readFile() {
  const filePath = path.join(__dirname, 'test-folder', 'note.txt');
  const data = await fs.readFile(filePath, 'utf8');
  console.log('File Content:\n---');
  console.log(data.trim());
  console.log('---');
}

readFile();