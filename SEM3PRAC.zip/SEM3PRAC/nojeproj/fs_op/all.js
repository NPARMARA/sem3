// node fs_op/all.js

const fs = require('fs').promises;
const path = require('path');

const dirPath = path.join(__dirname, 'test-folder');
const filePath = path.join(dirPath, 'note.txt');
const renamedFilePath = path.join(dirPath, 'renamed-note.txt');

async function runFileSystemOperations() {
  try {
    console.log('=== STARTING FILE SYSTEM OPERATIONS ===\n');

    // 1. CREATE A DIRECTORY (Folder)
    await fs.mkdir(dirPath, { recursive: true });
    console.log('1. Directory "test-folder" created successfully.');

    // 2. WRITE TO A FILE (Creates file and adds text)
    await fs.writeFile(filePath, 'Hello, this is the first line!\n');
    console.log('2. File "note.txt" created and written.');

    // 3. READ THE FILE
    const dataBeforeAppend = await fs.readFile(filePath, 'utf8');
    console.log('3. Reading file content:\n---');
    console.log(dataBeforeAppend.trim());
    console.log('---');

    // 4. APPEND TO A FILE (Adds text without overwriting)
    await fs.appendFile(filePath, 'This is an appended second line.\n');
    console.log('4. Data appended to "note.txt".');

    // Read again to verify append
    const dataAfterAppend = await fs.readFile(filePath, 'utf8');
    console.log('   Updated content:\n---');
    console.log(dataAfterAppend.trim());
    console.log('---');

    // 5. RENAME / MOVE A FILE
    await fs.rename(filePath, renamedFilePath);
    console.log('5. File renamed to "renamed-note.txt".');

    // 6. READ DIRECTORY CONTENTS (List files in folder)
    const files = await fs.readdir(dirPath);
    console.log('6. Files inside "test-folder":', files);

    // 7. DELETE A FILE
    await fs.unlink(renamedFilePath);
    console.log('7. File "renamed-note.txt" deleted.');

    // 8. REMOVE THE DIRECTORY
    await fs.rmdir(dirPath);
    console.log('8. Directory "test-folder" removed.');

    console.log('\n=== ALL FILE SYSTEM OPERATIONS COMPLETED SUCCESSFULLY! ===');

  } catch (error) {
    console.error('An error occurred during file operations:', error);
  }
}

runFileSystemOperations();