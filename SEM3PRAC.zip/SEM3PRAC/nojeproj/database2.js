// This script connects to MySQL, creates the database company_db, switches to it, and creates the emp table with eno and ename.

const mysql = require('mysql2');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'company_db'
});

db.connect((err) => {
  if (err) throw err;

  // 1. Insert five records
  const insertQuery = `
    INSERT INTO emp (eno, ename) VALUES 
    (101, 'John Doe'),
    (102, 'Alice Smith'),
    (103, 'Bob Johnson'),
    (104, 'Diana Prince'),
    (105, 'Charlie Brown')
  `;

  db.query(insertQuery, (err, result) => {
    if (err) throw err;
    console.log(`${result.affectedRows} records inserted successfully.\n`);

    // 2. Display all records ordered by name
    const selectQuery = 'SELECT * FROM emp ORDER BY ename ASC';
    db.query(selectQuery, (err, rows) => {
      if (err) throw err;
      console.log('--- Employee Records (Ordered by Name) ---');
      console.table(rows);
      db.end();
    });
  });
});