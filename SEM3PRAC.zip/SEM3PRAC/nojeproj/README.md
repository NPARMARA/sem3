22. Create an Express server with routes for /, /about and a 404 handler. (app.get, app.use)
23. Make a route with a route parameter (/student/:id) and one with a query string. (req.params, req.query)
24. Create a route with multiple callbacks and one using chained handlers. (next(), app.route().get().post())
25. Serve static files (HTML, CSS, images) from a public folder. (express.static)
26. Create an HTML form and show the submitted data. (express.urlencoded, req.body)
27. Upload a file with multer and show its name. (multer, upload.single, req.file)
28. Set, read and delete a cookie. (cookie-parser, res.cookie, req.cookies, res.clearCookie)
29. Send a file as a response and make another file downloadable. (res.sendFile, res.download)
30. Render a page with a template engine (EJS) showing a list of students. (app.set('view engine','ejs'), res.render)

---

Open your browser and test these URLs:

Q22: http://localhost:3000/about (or visit an invalid URL for 404)
Q23: http://localhost:3000/student/101?name=David
Q24: http://localhost:3000/multi
Q25: http://localhost:3000/index.html (Static file)
Q26 & Q27 & Q30: http://localhost:3000/ejs (Shows EJS list, form, and upload)
Q28: Visit /set-cookie, then /get-cookie, then /delete-cookie
Q29: Visit /send-file or /download-file