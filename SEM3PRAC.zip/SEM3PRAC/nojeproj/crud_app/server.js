const express = require("express");
const mysql = require("mysql2");
const path = require("path");

const app = express();
const PORT = 3000;

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(express.urlencoded({ extended: true }));

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "company_db",
});

db.connect((err) => {
  if (err) throw err;
  console.log("Connected to MySQL for CRUD app.");
});

app.get("/", (req, res) => {
  db.query("SELECT * FROM emp ORDER BY eno ASC", (err, rows) => {
    if (err) throw err;
    res.render("index", { employees: rows, editEmp: null });
  });
});

app.post("/add", (req, res) => {
  const { eno, ename } = req.body;
  db.query(
    "INSERT INTO emp (eno, ename) VALUES (?, ?)",
    [eno, ename],
    (err) => {
      if (err) throw err;
      res.redirect("/");
    },
  );
});

app.get("/edit/:eno", (req, res) => {
  const { eno } = req.params;
  db.query("SELECT * FROM emp WHERE eno = ?", [eno], (err, rows) => {
    if (err) throw err;
    db.query("SELECT * FROM emp ORDER BY eno ASC", (err, allRows) => {
      if (err) throw err;
      res.render("index", { employees: allRows, editEmp: rows[0] });
    });
  });
});

app.post("/update/:eno", (req, res) => {
  const { eno } = req.params;
  const { ename } = req.body;
  db.query("UPDATE emp SET ename = ? WHERE eno = ?", [ename, eno], (err) => {
    if (err) throw err;
    res.redirect("/");
  });
});

app.post("/delete/:eno", (req, res) => {
  const { eno } = req.params;
  db.query("DELETE FROM emp WHERE eno = ?", [eno], (err) => {
    if (err) throw err;
    res.redirect("/");
  });
});

app.listen(PORT, () => {
  console.log(`CRUD Server running at http://localhost:${PORT}`);
});
