const mysql = require("mysql2");

// 1. Connect to MySQL
const db = mysql.createConnection({
  host: "localhost",
  user: "root", // Change to your MySQL username
  password: "", // Change to your MySQL password
});

db.connect((err) => {
  if (err) throw err;
  console.log("Connected to MySQL!\n");

  // 2. Create Database and Table (Q19)
  db.query("CREATE DATABASE IF NOT EXISTS company_db", (err) => {
    if (err) throw err;

    db.changeUser({ database: "company_db" }, (err) => {
      if (err) throw err;

      const createTable = `
        CREATE TABLE IF NOT EXISTS emp (
          eno INT,
          ename VARCHAR(50)
        )
      `;
      db.query(createTable, (err) => {
        if (err) throw err;
        console.log("Database & Table created.");

        // 3. Insert 5 Records (Q20)
        const insertData = `
          INSERT INTO emp (eno, ename) VALUES 
          (1, 'John'),
          (2, 'Alice'),
          (3, 'Bob'),
          (4, 'David'),
          (5, 'Charlie')
        `;
        db.query(insertData, (err) => {
          if (err) throw err;
          console.log("5 records inserted.");

          // 4. Display Records Ordered by Name (Q20)
          db.query("SELECT * FROM emp ORDER BY ename ASC", (err, results) => {
            if (err) throw err;
            console.log("\n--- Records Ordered by Name ---");
            console.table(results);

            // 5. Update a Record (Q21)
            db.query("UPDATE emp SET ename = 'Johnny' WHERE eno = 1", (err) => {
              if (err) throw err;
              console.log("\nRecord updated.");

              // 6. Delete a Record (Q21)
              db.query("DELETE FROM emp WHERE eno = 5", (err) => {
                if (err) throw err;
                console.log("Record deleted.");

                // 7. Drop the Table (Q21)
                db.query("DROP TABLE emp", (err) => {
                  if (err) throw err;
                  console.log("Table dropped.");

                  db.end(); // Close connection
                });
              });
            });
          });
        });
      });
    });
  });
});
