const express = require("express");
const multer = require("multer");
const cookieParser = require("cookie-parser");
const path = require("path");

const app = express();
const upload = multer({ dest: "uploads/" });

// Setup View Engine & Middleware
app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

// -------------------------------------------------------------
// Q22: Basic Routes & 404 Handler
// -------------------------------------------------------------
app.get("/", (req, res) =>
  res.send("Home Page. Try visiting /about, /student/10?name=John, or /ejs"),
);
app.get("/about", (req, res) => res.send("About Page."));

// -------------------------------------------------------------
// Q23: Route Parameter & Query String
// -------------------------------------------------------------
app.get("/student/:id", (req, res) => {
  // Convert query object into formatted string (e.g., "name: john, age: 21")
  const queryFormatted = Object.entries(req.query)
    .map(([key, value]) => `${key}: ${value}`)
    .join(", ");

  res.send(
    `Student ID (Param): ${req.params.id} | Query Params: ${queryFormatted || "None"}`,
  );
});

// -------------------------------------------------------------
// Q24: Multiple Callbacks & Chained Handlers
// -------------------------------------------------------------
const mw1 = (req, res, next) => {
  console.log("Middleware 1");
  next();
};
const mw2 = (req, res, next) => {
  console.log("Middleware 2");
  next();
};
app.get("/multi", mw1, mw2, (req, res) =>
  res.send("Passed multiple callbacks!"),
);

app
  .route("/book")
  .get((req, res) => res.send("GET request for book route"))
  .post((req, res) => res.send("POST request for book route"));

// -------------------------------------------------------------
// Q26: HTML Form Submission (req.body)
// -------------------------------------------------------------
app.post("/submit", (req, res) => {
  res.send(`Form Submitted! Username: ${req.body.username}`);
});

// -------------------------------------------------------------
// Q27: File Upload with Multer (req.file)
// -------------------------------------------------------------
app.post("/upload", upload.single("myfile"), (req, res) => {
  res.send(`File uploaded successfully! File Name: ${req.file.originalname}`);
});

// -------------------------------------------------------------
// Q28: Set, Read, and Delete Cookies
// -------------------------------------------------------------
app.get("/set-cookie", (req, res) => {
  res.cookie("user", "Alice");
  res.send('Cookie "user" set successfully!');
});
app.get("/get-cookie", (req, res) => {
  res.send(`Read Cookie - User: ${req.cookies.user || "No cookie found"}`);
});
app.get("/delete-cookie", (req, res) => {
  res.clearCookie("user");
  res.send('Cookie "user" deleted!');
});

// -------------------------------------------------------------
// Q29: Send File & Download File
// -------------------------------------------------------------
app.get("/send-file", (req, res) => {
  res.sendFile(path.join(__dirname, "public/index.html"));
});
app.get("/download-file", (req, res) => {
  res.download(path.join(__dirname, "public/index.html"));
});

// -------------------------------------------------------------
// Q30: Render Page with EJS (List of Students)
// -------------------------------------------------------------
app.get("/ejs", (req, res) => {
  const students = [
    { id: 1, name: "John Doe" },
    { id: 2, name: "Alice Smith" },
    { id: 3, name: "Bob Johnson" },
  ];
  res.render("index", { students });
});

// Q22: 404 Handler (Must be at the very bottom)
app.use((req, res) => {
  res.status(404).send("404 - Page Not Found");
});

// Start Server
app.listen(3000, () => console.log("Server running on http://localhost:3000"));
