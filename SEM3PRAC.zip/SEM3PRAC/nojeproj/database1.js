//This script connects to MySQL, creates the database company_db, switches to it, and creates the emp table with eno and ename.

const mysql = require('mysql2');

// 1. Create a connection to MySQL server
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',      // Replace with your MySQL username
  password: '' // Replace with your MySQL password
});

db.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
    return;
  }
  console.log('Connected to MySQL server.');

  // 2. Create database
  const createDbQuery = 'CREATE DATABASE IF NOT EXISTS company_db';
  db.query(createDbQuery, (err, result) => {
    if (err) throw err;
    console.log('Database "company_db" created or already exists.');

    // 3. Select/Use the created database
    db.changeUser({ database: 'company_db' }, (err) => {
      if (err) throw err;

      // 4. Create emp table
      const createTableQuery = `
        CREATE TABLE IF NOT EXISTS emp (
          eno INT PRIMARY KEY,
          ename VARCHAR(100) NOT NULL
        )
      `;
      db.query(createTableQuery, (err, result) => {
        if (err) throw err;
        console.log('Table "emp" created successfully.');
        db.end(); // Close connection
      });
    });
  });
});