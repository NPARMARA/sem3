// This script demonstrates updating a record (UPDATE), removing a record (DELETE), and finally dropping the emp table (DROP TABLE).

const mysql = require("mysql2");

const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "company_db",
});

db.connect((err) => {
  if (err) throw err;

  // 1. UPDATE a record (Change name of eno 101)
  const updateQuery = "UPDATE emp SET ename = 'Johnathan Doe' WHERE eno = 101";
  db.query(updateQuery, (err, result) => {
    if (err) throw err;
    console.log(`Updated ${result.affectedRows} record(s).`);

    // 2. DELETE a record (Remove eno 105)
    const deleteQuery = "DELETE FROM emp WHERE eno = 105";
    db.query(deleteQuery, (err, result) => {
      if (err) throw err;
      console.log(`Deleted ${result.affectedRows} record(s).`);

      // 3. DROP the table
      const dropTableQuery = "DROP TABLE IF EXISTS emp";
      db.query(dropTableQuery, (err, result) => {
        if (err) throw err;
        console.log('Table "emp" dropped successfully.');
        db.end();
      });
    });
  });
});
