# Topic 03: Buffer (Binary Data Storage)

## Definition
A **Buffer** is a global class in Node.js designed to handle raw binary data directly in memory outside of the V8 JavaScript heap. Since JavaScript historically dealt only with string and number data, Buffers are critical for handling TCP streams, file system I/O, and multimedia processing.

## Core Buffer Methods
- `Buffer.alloc(size)`: Allocates a zero-filled buffer of specified size in bytes.
- `Buffer.from(string, encoding)`: Creates a new buffer from an array, string, or existing buffer.
- `buf.write(string)`: Writes a string into the buffer at a specified offset.
- `buf.toString(encoding)`: Decodes the buffer bytes into a string (`utf-8`, `hex`, `base64`).
- `Buffer.concat([b1, b2])`: Concatenates an array of buffers into a single buffer.
- `Buffer.compare(b1, b2)`: Compares two buffers lexicographically.

## How to Run
```bash
node buffer_demo.js
```
