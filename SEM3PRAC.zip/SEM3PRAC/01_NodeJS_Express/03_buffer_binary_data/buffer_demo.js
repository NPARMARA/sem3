// Topic 3: Buffer (Binary Data Storage)
// Demonstrates allocating, manipulating, converting, and streaming raw binary data

console.log('='.repeat(65));
console.log('  TOPIC 3: NODE.JS BUFFER (RAW BINARY DATA HANDLING)');
console.log('='.repeat(65));

// 1. Creating Buffers
console.log('\n[1] Creating Buffers:');
console.log('--------------------------------------------------');
// Buffer.alloc: Initializes buffer of given length zero-filled
const bufAlloc = Buffer.alloc(10);
console.log('Buffer.alloc(10)      :', bufAlloc);

// Buffer.from: Creates buffer from string with utf-8 encoding
const bufString = Buffer.from('Hello M.Sc. IT & CA', 'utf-8');
console.log('Buffer.from(string)   :', bufString);
console.log('Buffer byteLength     :', bufString.length, 'bytes');

// 2. Writing Data to a Buffer
console.log('\n[2] Writing Data to a Buffer:');
console.log('--------------------------------------------------');
const writableBuf = Buffer.alloc(20);
const bytesWritten = writableBuf.write('NodeJS');
console.log(`Bytes written: ${bytesWritten}, Content:`, writableBuf);
console.log('Decoded String:', writableBuf.toString('utf-8'));

// 3. Binary Encodings: UTF-8, Hex, and Base64
console.log('\n[3] Encodings (UTF-8, Hex, Base64):');
console.log('--------------------------------------------------');
const text = 'Saurashtra University';
const bufEncoding = Buffer.from(text);
console.log('Original Text :', text);
console.log('Hexadecimal   :', bufEncoding.toString('hex'));
console.log('Base64        :', bufEncoding.toString('base64'));

// Decoding Base64 back to text
const decodedFromBase64 = Buffer.from(bufEncoding.toString('base64'), 'base64').toString('utf-8');
console.log('Decoded Base64:', decodedFromBase64);

// 4. Slicing and Modifying Buffers (Memory reference)
console.log('\n[4] Buffer Slicing:');
console.log('--------------------------------------------------');
const originalBuf = Buffer.from('ABCDEFGH');
const sliceBuf = originalBuf.subarray(0, 4); // First 4 bytes
console.log('Original Buffer String:', originalBuf.toString());
console.log('Sliced Buffer (0 to 4) :', sliceBuf.toString());

// 5. Buffer Concatenation
console.log('\n[5] Buffer Concatenation (Buffer.concat):');
console.log('--------------------------------------------------');
const buf1 = Buffer.from('Semester 3 ');
const buf2 = Buffer.from('Practical Examination');
const combinedBuf = Buffer.concat([buf1, buf2]);
console.log('Combined Buffer:', combinedBuf.toString());

// 6. Buffer Comparison
console.log('\n[6] Buffer Comparison:');
console.log('--------------------------------------------------');
const bA = Buffer.from('Apple');
const bB = Buffer.from('Banana');
const comp = Buffer.compare(bA, bB);
console.log(`Buffer.compare("Apple", "Banana") = ${comp} (Negative means 'Apple' comes before 'Banana')`);
