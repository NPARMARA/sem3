# Topic 04: Node.js Module System

## Definition
A **Module** in Node.js is a reusable block of code whose existence doesn't accidentally impact other code. Each file in Node.js is treated as an isolated module.

### Module Classification:
1. **Core Modules**: Built into Node.js runtime (e.g., `fs`, `path`, `os`, `http`, `events`). No installation needed.
2. **Local Modules**: Custom files created by the application developer. Exported using `module.exports` or `exports`, and loaded using relative paths (`require('./mathOperations')`).
3. **Third-Party Modules**: Developed by the community and installed via NPM into `node_modules` (e.g., `express`, `ejs`, `mongoose`).

## How to Run
```bash
node modules_demo.js
```
