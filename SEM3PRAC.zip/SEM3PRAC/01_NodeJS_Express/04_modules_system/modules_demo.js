// Topic 4: Modules (Core, Local, and Third-Party)
// Demonstrates all 3 module types in Node.js

console.log('='.repeat(65));
console.log('  TOPIC 4: NODE.JS MODULE SYSTEM');
console.log('='.repeat(65));

// 1. CORE MODULES (Built-in with Node.js)
console.log('\n[1] Core Modules (path, os, url):');
console.log('--------------------------------------------------');
const path = require('path');
const os = require('os');
const { URL } = require('url');

console.log('Path Join Example  :', path.join('root', 'users', 'sem3', 'project.js'));
console.log('Path Extension     :', path.extname('document.pdf'));
console.log('OS Architecture    :', os.arch());
console.log('OS Free Memory     :', (os.freemem() / 1024 / 1024).toFixed(2), 'MB');

const sampleUrl = new URL('https://example.com:8080/students/search?dept=IT#top');
console.log('URL Hostname       :', sampleUrl.hostname);
console.log('URL Search Params  :', sampleUrl.searchParams.get('dept'));

// 2. LOCAL MODULES (Custom Developer Created)
console.log('\n[2] Local Custom Modules:');
console.log('--------------------------------------------------');
const math = require('./mathOperations');
const stringUtils = require('./stringUtils');

console.log('Using mathOperations module:');
console.log('  15 + 25 =', math.add(15, 25));
console.log('  10 * 8  =', math.multiply(10, 8));
console.log('  PI      =', math.PI);

console.log('\nUsing stringUtils module:');
console.log('  Capitalize "angular" :', stringUtils.capitalize('angular'));
console.log('  Reverse "nodejs"     :', stringUtils.reverse('nodejs'));
console.log('  Word count           :', stringUtils.countWords('Master of Science in IT'));

// 3. THIRD-PARTY MODULES (Installed via NPM into node_modules)
console.log('\n[3] Third-Party Modules:');
console.log('--------------------------------------------------');
console.log('Third-party modules are downloaded from the NPM registry.');
console.log('Example: require("express"), require("ejs"), require("cookie-parser")');
console.log('Node.js resolves them by looking inside the "node_modules" directory.');
