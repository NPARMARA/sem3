// Local Custom Module: stringUtils.js
// Exports functions individually using exports shortcut

exports.capitalize = function(str) {
  if (!str) return '';
  return str.charAt(0).toUpperCase() + str.slice(1);
};

exports.reverse = function(str) {
  if (!str) return '';
  return str.split('').reverse().join('');
};

exports.countWords = function(str) {
  if (!str) return 0;
  return str.trim().split(/\s+/).length;
};
