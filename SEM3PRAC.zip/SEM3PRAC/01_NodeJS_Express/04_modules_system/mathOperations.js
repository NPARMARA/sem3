// Local Custom Module: mathOperations.js
// Exports utility math functions using module.exports object

function add(a, b) {
  return a + b;
}

function subtract(a, b) {
  return a - b;
}

function multiply(a, b) {
  return a * b;
}

function divide(a, b) {
  if (b === 0) throw new Error('Division by zero is not allowed.');
  return a / b;
}

// Exporting as an object containing methods
module.exports = {
  add,
  subtract,
  multiply,
  divide,
  PI: 3.14159265359
};
