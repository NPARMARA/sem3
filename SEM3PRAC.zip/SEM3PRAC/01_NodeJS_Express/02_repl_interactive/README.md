# Topic 02: REPL (Read-Eval-Print Loop)

## Definition
**REPL** stands for **Read-Eval-Print Loop**. It is an interactive computer programming environment that takes single user inputs, executes them, and returns the result to the console. It is especially useful for inspecting code, rapid prototyping, and quick debugging.

## REPL Commands Reference
- `.help` : Show REPL command list
- `.break` : When editing a multiline expression, enter `.break` to abort
- `.clear` : Resets context object
- `.save <filename>` : Saves the current REPL session to a `.js` file
- `.load <filename>` : Evaluates a JavaScript file in the current REPL session
- `.exit` : Closes the I/O stream and exits REPL (or press `Ctrl + C` twice)
- `_` (Underscore): Variable that automatically holds the output of the most recently evaluated expression.

## Running the Demonstration
```bash
# Informational execution:
node custom_repl.js

# Interactive custom REPL mode:
node custom_repl.js --interactive
```
Inside the interactive prompt, test:
- `student.name`
- `greet("World")`
- `.syllabus`
- `_` (access last result)
