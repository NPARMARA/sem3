// Topic 2: REPL (Read-Eval-Print Loop)
// Demonstrates Node.js REPL mechanics and creates a programmable custom REPL shell

const repl = require('repl');

console.log('='.repeat(65));
console.log('  TOPIC 2: NODE.JS REPL (Read-Eval-Print Loop)');
console.log('='.repeat(65));
console.log(`
REPL Core Definition:
An interactive programming shell that:
1. READS JavaScript input from the user.
2. EVALUATES the code using V8 engine.
3. PRINTS the evaluated result back to stdout.
4. LOOPS the cycle until exited.

Built-in REPL Commands:
  .help   - Displays help on REPL commands
  .break  - Exits multiline expression
  .clear  - Clears context
  .save   - Saves current session to a file (e.g., .save session.js)
  .load   - Loads a file into the session (e.g., .load session.js)
  .exit   - Exits REPL
  _       - In standard REPL, underscore stores the result of last expression!
`);

// If run with --interactive flag, start interactive custom REPL
if (process.argv.includes('--interactive')) {
  console.log('Starting Custom Student REPL Environment...');
  const replServer = repl.start({
    prompt: 'mscit-sem3> '
  });

  // Pre-expose objects into the REPL context
  replServer.context.student = {
    name: 'Student User',
    course: 'M.Sc. (IT & CA)',
    semester: 3,
    college: 'Saurashtra University'
  };

  replServer.context.greet = (name) => `Hello, ${name}! Welcome to Node.js REPL!`;

  // Custom command
  replServer.defineCommand('syllabus', {
    help: 'Show MSCIT Sem 3 subjects',
    action() {
      console.log('Subjects: CS-13 Flutter | CS-14 Node.js | CS-15 Angular');
      this.displayPrompt();
    }
  });
} else {
  console.log('[Info] To launch the live interactive student REPL shell, run:');
  console.log('       node custom_repl.js --interactive\n');
  console.log('Demonstrating REPL expression evaluation programmatically:');
  
  // Programmatic simulation of REPL Evaluation
  const evalSimulation = (expr) => {
    try {
      const result = eval(expr);
      console.log(`Input: ${expr}  ==>  Output: ${result}`);
      return result;
    } catch (err) {
      console.log(`Input: ${expr}  ==>  Error: ${err.message}`);
    }
  };

  evalSimulation('25 * 4');
  evalSimulation('"Node.js " + "REPL"');
  evalSimulation('Math.sqrt(144)');
}
