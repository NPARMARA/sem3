# Topic 06: Event-Driven, Non-Blocking I/O Architecture

## Definition
**Event-Driven, Non-Blocking I/O** is the architectural backbone of Node.js.
- **Non-Blocking I/O**: Time-consuming operations (such as disk I/O, network requests, database queries) do not pause or block the single main execution thread. Instead, they run in the background (using `libuv` thread pool or OS kernels).
- **Event-Driven**: When background operations finish, they emit events or queue callback functions onto the Event Loop. The Event Loop dispatches these callbacks when the call stack is clear.

## Event Loop Execution Priority Order
1. **Synchronous JavaScript Code** (Top of Call Stack)
2. **`process.nextTick` Queue** (Fires immediately after current operation)
3. **Promise Microtask Queue** (`Promise.then()`, `async/await`)
4. **Timers Phase** (`setTimeout`, `setInterval`)
5. **I/O Polling Phase** (`fs.readFile`, TCP socket events)
6. **Check Phase** (`setImmediate`)
7. **Close Callbacks Phase** (`socket.on('close')`)

## How to Run
```bash
node event_loop_demo.js
```
