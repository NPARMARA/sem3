// Topic 6: Event-Driven, Non-Blocking I/O & Event Loop Order
// Compares Synchronous (blocking) vs Asynchronous (non-blocking) and traces Event Loop phases

const fs = require('fs');
const path = require('path');

console.log('='.repeat(65));
console.log('  TOPIC 6: EVENT-DRIVEN, NON-BLOCKING I/O & EVENT LOOP PHASES');
console.log('='.repeat(65));

// Create temporary file for demonstration
const tempFile = path.join(__dirname, 'sample.txt');
fs.writeFileSync(tempFile, 'This is a test file for demonstrating non-blocking I/O operations.');

// 1. Synchronous (BLOCKING) Demonstration
console.log('\n[1] Synchronous (Blocking) I/O Test:');
console.log('--------------------------------------------------');
const syncStart = Date.now();
console.log('[Sync 1] Before reading file synchronously');
const syncData = fs.readFileSync(tempFile, 'utf8');
console.log('[Sync 2] File read complete. Length:', syncData.length, 'chars');
console.log('[Sync 3] After reading file synchronously. Elapsed:', Date.now() - syncStart, 'ms');

// 2. Asynchronous (NON-BLOCKING) Demonstration & Event Loop Phasing
console.log('\n[2] Asynchronous (Non-Blocking) I/O & Event Loop Priority Test:');
console.log('--------------------------------------------------');

console.log('[Step 1] Synchronous top-level code executed');

// Macrotask: Timer phase
setTimeout(() => {
  console.log('[Step 6] Timer macrotask (setTimeout 0ms) executed in Timers Phase');
}, 0);

// Macrotask: Check phase
setImmediate(() => {
  console.log('[Step 7] Immediate macrotask (setImmediate) executed in Check Phase');
});

// Microtask: process.nextTick (Runs BEFORE any other microtask)
process.nextTick(() => {
  console.log('[Step 3] Microtask 1: process.nextTick executed (Highest priority microtask)');
});

// Microtask: Promise resolution
Promise.resolve().then(() => {
  console.log('[Step 4] Microtask 2: Promise.then executed (Standard microtask queue)');
});

// Non-blocking I/O: Poll phase
fs.readFile(tempFile, 'utf8', (err, data) => {
  if (err) throw err;
  console.log('[Step 8] I/O callback executed from Poll Phase. Content preview:', data.substring(0, 20));
  
  // Cleanup
  try { fs.unlinkSync(tempFile); } catch(e) {}
  console.log('\n[Complete] Non-blocking I/O demonstrated successfully!');
});

console.log('[Step 2] Synchronous top-level code completed! (Call stack empty, Event Loop processing queues)');
