# 🟢 01_NodeJS_Express: Complete Syllabus Practical Projects

This folder contains 10 dedicated, runnable individual sub-projects matching all 10 Node.js & Express definitions and syllabus topics for **M.Sc. (IT & CA) Semester 3 (CS-14 & CS-17 Practical)**:

---

## Index of Projects

| Folder | Topic / Concept | Main File | Key API / Feature |
| :--- | :--- | :--- | :--- |
| **`01_nodejs_runtime_basics/`** | 1. Node.js Runtime & V8 Engine | `runtime_basics.js` | `process`, V8 stats, memory, timers |
| **`02_repl_interactive/`** | 2. REPL Environment | `custom_repl.js` | `repl.start()`, commands, `_` variable |
| **`03_buffer_binary_data/`** | 3. Buffer & Binary Streams | `buffer_demo.js` | `Buffer.alloc()`, `Buffer.from()`, base64/hex |
| **`04_modules_system/`** | 4. Modules (Core, Local, 3rd-party) | `modules_demo.js` | `module.exports`, `exports`, `require()` |
| **`05_npm_package_manager/`** | 5. NPM Package Management | `npm_demo.js` | `package.json`, SemVer (`^`, `~`), scripts |
| **`06_event_driven_nonblocking/`** | 6. Event-Driven Non-Blocking I/O | `event_loop_demo.js` | Blocking vs Non-blocking, Event loop phases |
| **`07_event_emitter/`** | 7. EventEmitter Class | `event_emitter_demo.js` | `on()`, `once()`, `emit()`, class inheritance |
| **`08_express_web_server/`** | 8. Express.js Web Server & REST | `server.js` | `app.get()`, `post()`, `req.params`, `req.query` |
| **`09_express_middleware/`** | 9. Middleware Pipeline | `middleware_server.js` | App, router, static, error middleware |
| **`10_ejs_template_engine/`** | 10. EJS Template Engine | `ejs_server.js` | `<%= %>`, partials, looping, dynamic forms |

---

## Running Any Project

You can run any sub-project directly using standard `node`:
```bash
# Topic 1: Node runtime
node 01_nodejs_runtime_basics/runtime_basics.js

# Topic 2: REPL
node 02_repl_interactive/custom_repl.js

# Topic 3: Buffers
node 03_buffer_binary_data/buffer_demo.js

# Topic 4: Modules
node 04_modules_system/modules_demo.js

# Topic 5: NPM
node 05_npm_package_manager/npm_demo.js

# Topic 6: Non-blocking Event Loop
node 06_event_driven_nonblocking/event_loop_demo.js

# Topic 7: EventEmitter
node 07_event_emitter/event_emitter_demo.js

# Topic 8: Express Server (Port 3000)
node 08_express_web_server/server.js

# Topic 9: Express Middleware (Port 3001)
node 09_express_middleware/middleware_server.js

# Topic 10: EJS Web App (Port 3002)
node 10_ejs_template_engine/ejs_server.js
```
