# Topic 07: EventEmitter Class

## Definition
The **EventEmitter** is a fundamental class located in Node.js's core `events` module. It allows objects to emit named events that trigger registered callback functions (listeners). It forms the basis of many Node.js core modules, including `http.Server`, `fs.ReadStream`, and `net.Socket`.

## Key Methods
- `emitter.on(eventName, listener)`: Adds a listener function that is invoked every time the event is emitted.
- `emitter.once(eventName, listener)`: Adds a one-time listener function that is automatically removed after firing once.
- `emitter.emit(eventName, [...args])`: Synchronously calls each listener registered for the specified event in order, passing any arguments.
- `emitter.removeListener(eventName, listener)`: Removes a specific listener.
- `emitter.listenerCount(eventName)`: Returns the number of active listeners for an event.

## How to Run
```bash
node event_emitter_demo.js
```
