// Topic 7: EventEmitter Class & Custom Event Systems
// Demonstrates events module, on, once, emit, listener counts, and class inheritance

const EventEmitter = require('events');

console.log('='.repeat(65));
console.log('  TOPIC 7: NODE.JS EVENTEMITTER CLASS');
console.log('='.repeat(65));

// 1. Basic EventEmitter Instance
const simpleEmitter = new EventEmitter();

// Registering a listener with .on() (can fire multiple times)
simpleEmitter.on('login', (username, ipAddress) => {
  console.log(`[Event: login] User '${username}' logged in successfully from IP: ${ipAddress}`);
});

// Registering a one-time listener with .once()
simpleEmitter.once('welcome', (username) => {
  console.log(`[Event: welcome] Welcome banner shown to '${username}' (Runs ONCE only)`);
});

console.log('\n[1] Emitting standard events:');
simpleEmitter.emit('login', 'rahul_patel', '192.168.1.10');
simpleEmitter.emit('welcome', 'rahul_patel');

console.log('\n[2] Testing .once() vs .on() by emitting a second time:');
simpleEmitter.emit('login', 'rahul_patel', '192.168.1.10');
simpleEmitter.emit('welcome', 'rahul_patel'); // Will NOT fire because .once was consumed

// 2. Listener Count and Listener Management
console.log('\n[3] Listener Count Inspection:');
console.log('Number of "login" listeners:', simpleEmitter.listenerCount('login'));
console.log('Number of "welcome" listeners:', simpleEmitter.listenerCount('welcome'));

// 3. Extending EventEmitter in Custom Classes (Real-world Exam Pattern)
console.log('\n[4] Custom Class Extending EventEmitter:');
console.log('--------------------------------------------------');

class ExamResultSystem extends EventEmitter {
  publishResult(studentId, subject, marks) {
    console.log(`Processing result for Student ID: ${studentId}...`);
    
    if (marks >= 40) {
      this.emit('pass', { studentId, subject, marks });
    } else {
      this.emit('fail', { studentId, subject, marks });
    }
  }
}

const resultPortal = new ExamResultSystem();

// Register listeners for pass and fail events
resultPortal.on('pass', (data) => {
  console.log(` CONGRATS! Student ${data.studentId} PASSED ${data.subject} with ${data.marks}/100.`);
});

resultPortal.on('fail', (data) => {
  console.log(` NOTICE: Student ${data.studentId} FAILED ${data.subject} with ${data.marks}/100 (Re-exam required).`);
});

// Emitting from custom class
resultPortal.publishResult('MSC-101', 'CS-14 Node.js', 88);
resultPortal.publishResult('MSC-102', 'CS-14 Node.js', 32);
