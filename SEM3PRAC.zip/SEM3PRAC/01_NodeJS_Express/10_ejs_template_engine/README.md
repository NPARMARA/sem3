# Topic 10: Template Engine (EJS - Embedded JavaScript)

## Definition
A **Template Engine** allows developers to generate dynamic HTML markup on the server by injecting variables and executing JavaScript control flow (loops, conditionals) before sending the HTML response to the browser.
**EJS (Embedded JavaScript)** is one of the most popular template engines for Node.js and Express.

### EJS Syntax Tags:
- `<%= value %>`: Evaluates JavaScript and outputs the escaped HTML string.
- `<%- html %>`: Outputs the unescaped raw HTML string (used for partial includes `<%- include(...) %>`).
- `<% code %>`: Scriptlet tag for control-flow logic (loops `forEach`, conditionals `if...else`) with no output.
- `<%# comment %>`: Server-side comment (omitted from final HTML).

## How to Run
```bash
node ejs_server.js
```
Then visit in browser:
- `http://localhost:3002/` (Home page with partials)
- `http://localhost:3002/students` (Dynamic table with condition highlighting)
- `http://localhost:3002/add-student` (Interactive form to add students via POST)
