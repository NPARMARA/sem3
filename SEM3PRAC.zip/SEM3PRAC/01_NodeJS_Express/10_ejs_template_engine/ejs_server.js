// Topic 10: Template Engine (EJS - Embedded JavaScript)
// Demonstrates server-side templating, dynamic data passing, partials, and form submission

const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3002;

// 1. Configure EJS View Engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// 2. Middleware to parse URL-encoded request bodies from HTML forms
app.use(express.urlencoded({ extended: true }));

// In-memory student records
let studentDatabase = [
  { id: 101, name: 'Bhavik Dave', subject: 'CS-14: Node.js & Express', marks: 88 },
  { id: 102, name: 'Kavita Joshi', subject: 'CS-15: Angular Web Framework', marks: 92 },
  { id: 103, name: 'Sanjay Jadeja', subject: 'CS-13: Flutter App Development', marks: 45 },
  { id: 104, name: 'Ritu Trivedi', subject: 'CS-14: Node.js & Express', marks: 74 }
];

// Route 1: Home page
app.get('/', (req, res) => {
  res.render('index', {
    title: 'Home',
    college: 'Saurashtra University - Department of Computer Science',
    subject: 'CS-14 Node.js & Express',
    semester: 'Semester 3',
    studentCount: studentDatabase.length
  });
});

// Route 2: Student list view
app.get('/students', (req, res) => {
  res.render('students', {
    title: 'Student Roster',
    students: studentDatabase
  });
});

// Route 3: Form to add student (GET)
app.get('/add-student', (req, res) => {
  res.render('add_student', {
    title: 'Add New Student'
  });
});

// Route 4: Handle form submission (POST)
app.post('/add-student', (req, res) => {
  const { name, subject, marks } = req.body;
  if (name && subject && marks !== undefined) {
    const newId = studentDatabase.length ? Math.max(...studentDatabase.map(s => s.id)) + 1 : 101;
    studentDatabase.push({
      id: newId,
      name,
      subject,
      marks: parseInt(marks)
    });
  }
  // Redirect back to student list to view newly rendered student
  res.redirect('/students');
});

// Start Server
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`EJS Web Application running on: http://localhost:${PORT}`);
  });
}

module.exports = app;
