// Topic 5: Node Package Manager (NPM)
// Demonstrates package management concepts, semantic versioning, and package.json manifest

const fs = require('fs');
const path = require('path');

console.log('='.repeat(65));
console.log('  TOPIC 5: NPM (NODE PACKAGE MANAGER) EXPLAINED');
console.log('='.repeat(65));

// Read package.json manifest
const pkgPath = path.join(__dirname, 'package.json');
const pkgData = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));

console.log('\n[1] Current Project Metadata from package.json:');
console.log('--------------------------------------------------');
console.log('Package Name   :', pkgData.name);
console.log('Version        :', pkgData.version);
console.log('Main Entrypoint:', pkgData.main);
console.log('Scripts        :', Object.keys(pkgData.scripts).join(', '));

console.log('\n[2] Core NPM Concepts for Exams:');
console.log('--------------------------------------------------');
console.log('1. Local Installation  : npm install <pkg>       (Installs into ./node_modules)');
console.log('2. Global Installation : npm install -g <pkg>    (Installs globally for CLI use)');
console.log('3. Development Dep     : npm install -D <pkg>    (Installs in "devDependencies")');
console.log('4. Production Dep      : npm install <pkg>       (Installs in "dependencies")');
console.log('5. Package Manifest    : package.json            (Project metadata and dependencies)');
console.log('6. Lockfile            : package-lock.json       (Exact locked dependency versions)');

console.log('\n[3] Semantic Versioning (SemVer: MAJOR.MINOR.PATCH):');
console.log('--------------------------------------------------');
console.log('Example: ^1.2.3');
console.log('  - MAJOR (1): Incompatible API breaking changes');
console.log('  - MINOR (2): Backwards-compatible new features');
console.log('  - PATCH (3): Backwards-compatible bug fixes');
console.log('Prefixes:');
console.log('  ^1.2.3 => Allows updates to any 1.x.x (Minor & Patch updates allowed)');
console.log('  ~1.2.3 => Allows updates to 1.2.x only (Patch updates allowed only)');
console.log('   1.2.3 => Exact version match only');
