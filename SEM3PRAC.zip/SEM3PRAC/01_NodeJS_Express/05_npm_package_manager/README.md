# Topic 05: NPM (Node Package Manager)

## Definition
**NPM (Node Package Manager)** is the world's largest software registry and the default package manager for Node.js. It consists of:
1. The **NPM Website**: For discovering and browsing packages.
2. The **NPM Registry**: An online database of JavaScript packages.
3. The **NPM CLI**: The command-line client used to install, update, and manage dependencies.

## Key Commands
- `npm init -y`: Initializes a new `package.json` with default settings.
- `npm install <pkg>`: Installs a module locally.
- `npm install <pkg> --save-dev` (or `-D`): Saves to `devDependencies`.
- `npm install -g <pkg>`: Installs a module globally.
- `npm run <script>`: Runs a defined script from `package.json`.

## How to Run
```bash
# Execute the demonstration
node npm_demo.js

# Or via npm script
npm start
npm test
```
