# Topic 09: Express.js Middleware Pipeline

## Definition
**Middleware** functions in Express are functions that have access to the request object (`req`), response object (`res`), and the `next` function in the application’s request-response cycle.

### Middleware Capabilities:
1. Execute any code.
2. Make changes to the `req` and `res` objects.
3. End the request-response cycle.
4. Call the next middleware in the stack using `next()`.

### Types of Middleware Demonstrated:
- **Application-level**: `app.use((req, res, next) => ...)`
- **Built-in**: `express.json()`, `express.urlencoded()`, `express.static()`
- **Third-party**: `cookie-parser`
- **Route-level Guard**: `app.get('/admin', checkAuth, handler)`
- **Error-handling**: `app.use((err, req, res, next) => ...)` (identified by 4 parameters)

## How to Run
```bash
node middleware_server.js
```
Test in browser:
- `http://localhost:3001/`
- `http://localhost:3001/index.html` (Static file)
- `http://localhost:3001/set-cookie` & `/read-cookie`
- `http://localhost:3001/admin/dashboard` (Unauthorized without token)
- `http://localhost:3001/admin/dashboard?token=secret123` (Authorized)
- `http://localhost:3001/cause-error` (Triggers 4-argument error handler)
