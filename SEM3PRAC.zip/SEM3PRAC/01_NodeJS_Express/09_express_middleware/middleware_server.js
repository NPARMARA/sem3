// Topic 9: Middleware in Express.js
// Demonstrates Application-level, Router-level, Built-in, Third-party, and Error-handling middleware

const express = require('express');
const cookieParser = require('cookie-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3001;

// 1. APPLICATION-LEVEL MIDDLEWARE: Custom Logger
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  console.log(`[LOGGER] ${timestamp} | ${req.method} ${req.url}`);
  next(); // Pass control to the next middleware in the pipeline
});

// 2. APPLICATION-LEVEL MIDDLEWARE: Request Timing Tracker
app.use((req, res, next) => {
  req.requestTime = Date.now();
  next();
});

// 3. BUILT-IN MIDDLEWARE
// Parse application/json payloads
app.use(express.json());
// Parse application/x-www-form-urlencoded form data
app.use(express.urlencoded({ extended: true }));
// Serve static assets from 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// 4. THIRD-PARTY MIDDLEWARE: cookie-parser
app.use(cookieParser());

// 5. ROUTE-SPECIFIC AUTHENTICATION MIDDLEWARE (Route Guard)
const checkAuth = (req, res, next) => {
  const authHeader = req.headers['authorization'] || req.query.token;
  if (authHeader === 'secret123') {
    next(); // Authorized! Proceed to route handler
  } else {
    res.status(401).json({
      error: 401,
      message: 'Unauthorized! Pass token "secret123" via query ?token=secret123 or Authorization header.'
    });
  }
};

// Public Routes
app.get('/', (req, res) => {
  const duration = Date.now() - req.requestTime;
  res.json({
    message: 'Express Middleware Pipeline Active',
    processingTimeMs: duration,
    routes: {
      publicStatic: 'http://localhost:' + PORT + '/index.html',
      cookies: 'http://localhost:' + PORT + '/set-cookie (then /read-cookie)',
      protected: 'http://localhost:' + PORT + '/admin/dashboard?token=secret123',
      triggerError: 'http://localhost:' + PORT + '/cause-error'
    }
  });
});

// Cookie Management Routes
app.get('/set-cookie', (req, res) => {
  res.cookie('mscitUser', 'JohnDoe', { maxAge: 900000, httpOnly: true });
  res.send('Cookie "mscitUser" has been set. Visit /read-cookie to inspect.');
});

app.get('/read-cookie', (req, res) => {
  res.json({ cookiesReceived: req.cookies });
});

app.get('/clear-cookie', (req, res) => {
  res.clearCookie('mscitUser');
  res.send('Cookie "mscitUser" cleared successfully.');
});

// Protected Route guarded by checkAuth middleware
app.get('/admin/dashboard', checkAuth, (req, res) => {
  res.json({
    message: 'Welcome to the Protected Admin Dashboard!',
    authStatus: 'Verified'
  });
});

// Route designed to demonstrate Error-Handling Middleware
app.get('/cause-error', (req, res, next) => {
  const intentionalError = new Error('This is a simulated uncaught server error.');
  intentionalError.status = 500;
  next(intentionalError); // Forward to error-handling middleware
});

// 6. GLOBAL ERROR-HANDLING MIDDLEWARE (Notice the 4 arguments: err, req, res, next)
app.use((err, req, res, next) => {
  console.error('[ERROR HANDLER]', err.message);
  res.status(err.status || 500).json({
    error: {
      type: 'Server Error Handler',
      message: err.message,
      statusCode: err.status || 500
    }
  });
});

// Start Server
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Middleware server running on: http://localhost:${PORT}`);
  });
}

module.exports = app;
