// Topic 1: Node.js Runtime Basics
// Demonstrates Node.js as an asynchronous JavaScript runtime built on Chrome's V8 engine

console.log('='.repeat(60));
console.log('  NODE.JS RUNTIME ENVIRONMENT BASICS');
console.log('='.repeat(60));

// 1. V8 Engine & Process Information
console.log('\n[1] Node.js & V8 Runtime Information:');
console.log('--------------------------------------');
console.log('Node.js Version  :', process.version);
console.log('V8 Engine Version:', process.versions.v8);
console.log('Operating System :', process.platform, process.arch);
console.log('Current Process ID (PID):', process.pid);
console.log('Process Uptime   :', process.uptime().toFixed(2), 'seconds');

// 2. Memory Usage Statistics
console.log('\n[2] Process Memory Usage:');
console.log('--------------------------------------');
const mem = process.memoryUsage();
console.log('RSS (Resident Set Size) :', (mem.rss / 1024 / 1024).toFixed(2), 'MB');
console.log('Heap Total              :', (mem.heapTotal / 1024 / 1024).toFixed(2), 'MB');
console.log('Heap Used               :', (mem.heapUsed / 1024 / 1024).toFixed(2), 'MB');

// 3. Command Line Arguments (process.argv)
console.log('\n[3] Command Line Arguments (process.argv):');
console.log('--------------------------------------');
process.argv.forEach((arg, index) => {
  console.log(`argv[${index}] = ${arg}`);
});

// 4. Asynchronous Timer Demonstration (V8 Event Loop)
console.log('\n[4] Asynchronous Timers (Non-blocking):');
console.log('--------------------------------------');
console.log('1. Starting synchronous execution block');

setTimeout(() => {
  console.log('3. [Async Callback] Executed from Timer Queue after 500ms delay');
  console.log('\n[5] Runtime Basics execution finished successfully!');
}, 500);

console.log('2. Ending synchronous execution block (before async timer completes)');
