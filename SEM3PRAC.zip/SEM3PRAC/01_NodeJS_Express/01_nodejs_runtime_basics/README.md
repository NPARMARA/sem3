# Topic 01: Node.js Runtime Basics

## Definition
**Node.js** is an open-source, cross-platform JavaScript runtime environment built on Google Chrome's V8 JavaScript engine. It executes JavaScript code outside a web browser, enabling server-side execution with an event-driven, non-blocking I/O model.

## Key Concepts Demonstrated
1. **Google V8 Engine**: Compiles JavaScript directly into native machine code.
2. **`process` Global Object**: Accesses system architecture, OS platform, memory usage, and command-line arguments.
3. **Non-blocking Execution**: Timers (`setTimeout`) execute asynchronously without halting synchronous code execution.

## How to Run
```bash
node runtime_basics.js
# Or with command line arguments:
node runtime_basics.js param1 param2
```
