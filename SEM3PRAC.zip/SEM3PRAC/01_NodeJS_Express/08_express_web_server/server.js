// Topic 8: Express.js Web Application Framework
// Demonstrates Express server, REST endpoints, route parameters, queries, and chained handlers

const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

// Built-in middleware to parse incoming JSON payloads
app.use(express.json());

// In-memory student dataset
let students = [
  { id: 101, name: 'Rahul Sharma', course: 'M.Sc. IT & CA', semester: 3, grade: 'A' },
  { id: 102, name: 'Priya Patel', course: 'M.Sc. IT & CA', semester: 3, grade: 'A+' },
  { id: 103, name: 'Amit Mehta', course: 'M.Sc. IT & CA', semester: 3, grade: 'B+' }
];

// 1. Root Route
app.get('/', (req, res) => {
  res.json({
    status: 'success',
    message: 'Welcome to MSCIT Sem 3 Express.js API Server!',
    endpoints: [
      'GET    /about',
      'GET    /api/students',
      'GET    /api/students?semester=3',
      'GET    /api/students/:id',
      'POST   /api/students',
      'PUT    /api/students/:id',
      'DELETE /api/students/:id',
      'GET/POST /api/courses (chained routes)'
    ]
  });
});

// 2. Simple Route
app.get('/about', (req, res) => {
  res.send('<h1>About Express.js Server</h1><p>Minimal, flexible Node.js web application framework.</p>');
});

// 3. Query String Handling (req.query)
// Example: /api/students or /api/students?semester=3
app.get('/api/students', (req, res) => {
  const { semester } = req.query;
  if (semester) {
    const filtered = students.filter(s => s.semester === parseInt(semester));
    return res.json({ count: filtered.length, data: filtered });
  }
  res.json({ count: students.length, data: students });
});

// 4. Route Parameter Handling (req.params)
// Example: /api/students/101
app.get('/api/students/:id', (req, res) => {
  const studentId = parseInt(req.params.id);
  const student = students.find(s => s.id === studentId);
  
  if (!student) {
    return res.status(404).json({ error: `Student with ID ${studentId} not found.` });
  }
  res.json({ status: 'success', data: student });
});

// 5. POST Request to Create Data (req.body)
app.post('/api/students', (req, res) => {
  const { name, course, semester, grade } = req.body;
  if (!name || !course) {
    return res.status(400).json({ error: 'Name and Course are required fields.' });
  }

  const newStudent = {
    id: students.length ? Math.max(...students.map(s => s.id)) + 1 : 101,
    name,
    course,
    semester: semester || 3,
    grade: grade || 'A'
  };

  students.push(newStudent);
  res.status(201).json({ message: 'Student created successfully', data: newStudent });
});

// 6. PUT Request to Update Data
app.put('/api/students/:id', (req, res) => {
  const studentId = parseInt(req.params.id);
  const student = students.find(s => s.id === studentId);

  if (!student) {
    return res.status(404).json({ error: `Student with ID ${studentId} not found.` });
  }

  if (req.body.name) student.name = req.body.name;
  if (req.body.grade) student.grade = req.body.grade;

  res.json({ message: 'Student updated successfully', data: student });
});

// 7. DELETE Request
app.delete('/api/students/:id', (req, res) => {
  const studentId = parseInt(req.params.id);
  const index = students.findIndex(s => s.id === studentId);

  if (index === -1) {
    return res.status(404).json({ error: `Student with ID ${studentId} not found.` });
  }

  const removed = students.splice(index, 1);
  res.json({ message: 'Student deleted successfully', deleted: removed[0] });
});

// 8. Chained Route Handlers (app.route)
app.route('/api/courses')
  .get((req, res) => {
    res.json({ courses: ['CS-13: Flutter', 'CS-14: Node.js', 'CS-15: Angular'] });
  })
  .post((req, res) => {
    res.json({ message: `Course "${req.body.courseTitle}" registered successfully` });
  });

// 9. 404 Not Found Handler
app.use((req, res) => {
  res.status(404).json({ error: 404, message: `Route ${req.originalUrl} not found.` });
});

// Start Server
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Express server running on: http://localhost:${PORT}`);
  });
}

module.exports = app;
