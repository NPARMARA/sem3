# Topic 08: Express.js Web Application Framework

## Definition
**Express.js** is a fast, unopinionated, minimalist web framework for Node.js. It simplifies building robust web servers and RESTful APIs by providing a powerful routing layer, middleware integration, HTTP utility methods, and template engine rendering.

## Core Features Demonstrated
1. **HTTP Methods**: `app.get()`, `app.post()`, `app.put()`, `app.delete()`
2. **Route Parameters**: `req.params` (`/api/students/:id`)
3. **Query Strings**: `req.query` (`/api/students?semester=3`)
4. **Chained Route Handlers**: `app.route('/api/courses').get().post()`
5. **JSON Responses**: `res.json()`, `res.status()`
6. **404 Catch-All Handler**: `app.use((req, res) => ...)`

## How to Run
```bash
node server.js
```
Then visit in browser or test using curl / Postman:
- `http://localhost:3000/`
- `http://localhost:3000/about`
- `http://localhost:3000/api/students`
- `http://localhost:3000/api/students/101`
- `http://localhost:3000/api/students?semester=3`
- `http://localhost:3000/api/courses`
