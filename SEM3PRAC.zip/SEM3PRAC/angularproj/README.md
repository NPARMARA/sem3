# Angular 3-in-1 Practical Projects

This workspace contains 3 independent, runnable Angular projects:

---

## 1. Login Project (`login-app`)
* **Features**: Simple login form (Username & Password), credentials validation, and redirection to Homepage with Logout.
* **Default Credentials**: `admin` / `123`
* **Default Port**: `http://localhost:4200`
* **Run Command**:
  ```bash
  npm run start:login
  # or: ng serve login-app --open
  ```

---

## 2. CRUD Operations Project (`crud-app`)
* **Features**: Simple Employee CRUD (Create, Read, Update, Delete) operations with ENO and ENAME, interactive Add/Edit form, confirmation for delete, and persistent storage.
* **Default Port**: `http://localhost:4201`
* **Run Command**:
  ```bash
  npm run start:crud
  # or: ng serve crud-app --open
  ```

---

## 3. Routing Pages Project (`routing-app`)
* **Features**: Navigation bar with active route highlighting between **Page A** and **Page B** using Angular Router (`RouterOutlet`, `RouterLink`, `RouterLinkActive`).
* **Default Port**: `http://localhost:4202`
* **Run Command**:
  ```bash
  npm run start:routing
  # or: ng serve routing-app --open
  ```

---

## Build Commands
To compile/build all three projects at once:
```bash
npm run build:all
```
Or individually:
```bash
npm run build:login
npm run build:crud
npm run build:routing
```
