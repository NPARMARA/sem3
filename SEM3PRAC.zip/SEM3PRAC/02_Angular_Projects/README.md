# 🔵 02_Angular_Projects: Complete Practical Workspace

This workspace contains dedicated, runnable Angular projects covering all 10 Angular definitions and core syllabus topics for **M.Sc. (IT & CA) Semester 3 (CS-15 & CS-17 Practical)**:

---

## Index of Projects & Topics

| Project | Topics Covered | Key Concepts & Features | Run Command |
| :--- | :--- | :--- | :--- |
| **`databinding-app`** | 1. Angular<br>2. SPA<br>3. Component<br>4. Data Binding | Component anatomy (TS Class, Template, Styles, Metadata), Interpolation `{{ }}`, Property `[property]`, Event `(event)`, Two-Way `[(ngModel)]` | `npm run start:databinding` |
| **`directives-pipes-app`** | 5. Directives<br>6. Pipes | Structural (`*ngIf`, `*ngFor`), Attribute (`ngClass`, `ngStyle`), Built-in pipes (`uppercase`, `date`, `currency`, `percent`, `json`), Custom `GradePipe` | `npm run start:directives-pipes` |
| **`services-di-app`** | 7. Services<br>8. Dependency Injection (DI) | Reusable `@Injectable` singleton service, constructor-based DI, Observable data streams | `npm run start:services-di` |
| **`routing-app`** | 9. Routing & Navigation | `RouterOutlet`, `RouterLink`, `RouterLinkActive`, Page navigation without browser reloads | `npm run start:routing` |
| **`reactive-forms-app`** | 10. Reactive Forms | Model-driven forms, `FormGroup`, `FormControl`, `Validators` (`required`, `minLength`, `email`, `min/max`), real-time error states | `npm run start:reactive-forms` |
| **`login-app`** | Authentication Practical | Login validation, route guard redirect, session storage, logout | `npm run start:login` |
| **`crud-app`** | Master Employee CRUD | Complete Add, Edit, Delete, Read operations with persistent storage | `npm run start:crud` |

---

## How to Install & Run

1. Open a terminal in `02_Angular_Projects`:
   ```bash
   cd 02_Angular_Projects
   npm install
   ```

2. Run any project individually using Angular CLI or npm scripts:
   ```bash
   # Run Data Binding & Component app (Port 4203)
   npm run start:databinding

   # Run Directives & Pipes app (Port 4204)
   npm run start:directives-pipes

   # Run Services & Dependency Injection app (Port 4205)
   npm run start:services-di

   # Run Reactive Forms validation app (Port 4206)
   npm run start:reactive-forms

   # Run Page Routing app (Port 4202)
   npm run start:routing

   # Run Login app (Port 4200)
   npm run start:login

   # Run Employee CRUD app (Port 4201)
   npm run start:crud
   ```
