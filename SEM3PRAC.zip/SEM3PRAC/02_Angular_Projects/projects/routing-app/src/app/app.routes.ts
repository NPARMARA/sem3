import { Routes } from '@angular/router';
import { PageAComponent } from './page-a.component';
import { PageBComponent } from './page-b.component';

export const routes: Routes = [
  { path: 'page-a', component: PageAComponent },
  { path: 'page-b', component: PageBComponent },
  { path: '', redirectTo: 'page-a', pathMatch: 'full' }
];