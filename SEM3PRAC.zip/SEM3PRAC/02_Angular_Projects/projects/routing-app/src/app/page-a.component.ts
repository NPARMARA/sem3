import { Component } from '@angular/core';

@Component({
  selector: 'app-page-a',
  standalone: true,
  template: `<h3 style="color: #007bff;">Welcome to Page A!</h3><p>This is Page A content.</p>`
})
export class PageAComponent {}