import { Component } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <style>
      .container {
        max-width: 700px;
        margin: 40px auto;
        padding: 25px;
        border: 2px solid #ccc;
      }
      h2 {
        text-align: center;
        margin-top: 0;
        color: #333;
      }
      .nav-bar {
        margin-bottom: 25px;
        padding: 12px;
        border: 1px solid #ddd;
      }
      .nav-link {
        text-decoration: none;
        padding: 8px 18px;
        border-radius: 4px;
        font-weight: bold;
        color: #007bff;
        
      }
      .nav-link.active {
        background-color: #007bff !important;
        color: white !important;
      }
      .content-box {
        min-height: 120px;
        padding: 15px;
        border: 1px dashed #ccc;
        background: #fff;
      }
    </style>

    <div class="container">
      <h2>Angular Routing</h2>

      <nav class="nav-bar">
        <a routerLink="/page-a" routerLinkActive="active" class="nav-link">Page A</a>
        <a routerLink="/page-b" routerLinkActive="active" class="nav-link">Page B</a>
      </nav>

      <div class="content-box">
        <router-outlet></router-outlet>
      </div>
    </div>
  `
})
export class AppComponent {}