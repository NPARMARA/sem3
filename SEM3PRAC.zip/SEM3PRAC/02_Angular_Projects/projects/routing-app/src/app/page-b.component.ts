import { Component } from '@angular/core';

@Component({
  selector: 'app-page-b',
  standalone: true,
  template: `<h3 style="color: #28a745;">Welcome to Page B!</h3><p>This is Page B content...</p>`
})
export class PageBComponent {}