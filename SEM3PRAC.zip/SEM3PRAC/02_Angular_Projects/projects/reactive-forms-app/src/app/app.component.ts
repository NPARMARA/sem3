import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  template: `
    <div class="card">
      <header class="header">
        <h2>Angular Reactive Forms with Validation</h2>
        <p>Demonstrating Model-Driven Forms, FormGroup, FormControl, Validators, and Real-Time State Inspection.</p>
      </header>

      <section class="content">
        <form [formGroup]="studentForm" (ngSubmit)="onSubmit()" class="form">
          <!-- ROLL NUMBER -->
          <div class="form-group">
            <label>Roll Number (Required, Min: 100):</label>
            <input type="number" formControlName="rollNo" class="input" />
            <div *ngIf="rollNo?.invalid && (rollNo?.dirty || rollNo?.touched)" class="error">
              <span *ngIf="rollNo?.errors?.['required']">Roll number is required.</span>
              <span *ngIf="rollNo?.errors?.['min']">Roll number must be at least 100.</span>
            </div>
          </div>

          <!-- FULL NAME -->
          <div class="form-group">
            <label>Full Name (Required, Min 3 chars):</label>
            <input type="text" formControlName="fullName" class="input" placeholder="e.g. Rahul Patel" />
            <div *ngIf="fullName?.invalid && (fullName?.dirty || fullName?.touched)" class="error">
              <span *ngIf="fullName?.errors?.['required']">Full Name is required.</span>
              <span *ngIf="fullName?.errors?.['minlength']">Name must be at least 3 characters.</span>
            </div>
          </div>

          <!-- EMAIL -->
          <div class="form-group">
            <label>Email Address (Email format validation):</label>
            <input type="email" formControlName="email" class="input" placeholder="student@example.com" />
            <div *ngIf="email?.invalid && (email?.dirty || email?.touched)" class="error">
              <span *ngIf="email?.errors?.['required']">Email address is required.</span>
              <span *ngIf="email?.errors?.['email']">Please enter a valid email address.</span>
            </div>
          </div>

          <!-- MARKS -->
          <div class="form-group">
            <label>Internal Exam Marks (0 to 100):</label>
            <input type="number" formControlName="marks" class="input" />
            <div *ngIf="marks?.invalid && (marks?.dirty || marks?.touched)" class="error">
              <span *ngIf="marks?.errors?.['required']">Marks are required.</span>
              <span *ngIf="marks?.errors?.['min'] || marks?.errors?.['max']">Marks must be between 0 and 100.</span>
            </div>
          </div>

          <div class="actions">
            <button type="submit" [disabled]="studentForm.invalid" class="btn btn-submit">
              Submit Validated Form
            </button>
            <button type="button" (click)="resetForm()" class="btn btn-reset">
              Reset
            </button>
          </div>
        </form>

        <!-- LIVE FORM STATE DIAGNOSTICS -->
        <div class="diagnostics">
          <h4>Reactive Form State Inspector:</h4>
          <p>Form Status: <strong [style.color]="studentForm.valid ? '#2e7d32' : '#c62828'">{{ studentForm.valid ? 'VALID' : 'INVALID' }}</strong></p>
          <p>Pristine (untouched): <strong>{{ studentForm.pristine }}</strong> | Dirty (modified): <strong>{{ studentForm.dirty }}</strong></p>
          <p>Current Form Values (JSON):</p>
          <pre>{{ studentForm.value | json }}</pre>
        </div>

        <div *ngIf="submittedData" class="success-box">
          <h4> Form Submitted Successfully!</h4>
          <p>Recorded Student: <strong>{{ submittedData.fullName }}</strong> (Roll: {{ submittedData.rollNo }}), Marks: {{ submittedData.marks }}%</p>
        </div>
      </section>
    </div>
  `,
  styles: [`
    .card { max-width: 700px; margin: 0 auto; background: white; border-radius: 8px; box-shadow: 0 4px 16px rgba(0,0,0,0.08); overflow: hidden; }
    .header { background: #6a1b9a; color: white; padding: 22px 25px; }
    .header h2 { margin: 0; }
    .header p { margin: 6px 0 0 0; opacity: 0.9; font-size: 14px; }
    .content { padding: 25px; }
    .form-group { margin-bottom: 18px; }
    label { display: block; font-weight: 600; margin-bottom: 6px; color: #37474f; font-size: 14px; }
    .input { width: 100%; box-sizing: border-box; padding: 10px 12px; border: 1px solid #cfd8dc; border-radius: 4px; font-size: 14px; }
    .input:focus { border-color: #6a1b9a; outline: none; }
    .error { color: #d32f2f; font-size: 13px; margin-top: 4px; font-weight: 500; }
    .actions { display: flex; gap: 10px; margin-top: 20px; }
    .btn { padding: 10px 20px; border: none; border-radius: 4px; font-weight: 600; cursor: pointer; }
    .btn-submit { background: #6a1b9a; color: white; }
    .btn-submit:disabled { background: #b39ddb; cursor: not-allowed; }
    .btn-reset { background: #90a4ae; color: white; }
    .diagnostics { margin-top: 30px; background: #f3e5f5; border-left: 4px solid #ab47bc; padding: 15px; border-radius: 4px; }
    .diagnostics h4 { margin-top: 0; color: #4a148c; }
    pre { background: #263238; color: #80cbc4; padding: 10px; border-radius: 4px; font-size: 13px; margin: 0; }
    .success-box { margin-top: 20px; background: #e8f5e9; border: 1px solid #81c784; padding: 15px; border-radius: 4px; color: #1b5e20; }
  `]
})
export class AppComponent implements OnInit {
  studentForm!: FormGroup;
  submittedData: any = null;

  ngOnInit(): void {
    // Initializing Reactive FormGroup with explicit FormControls and Validators
    this.studentForm = new FormGroup({
      rollNo: new FormControl(101, [Validators.required, Validators.min(100)]),
      fullName: new FormControl('', [Validators.required, Validators.minLength(3)]),
      email: new FormControl('', [Validators.required, Validators.email]),
      marks: new FormControl(85, [Validators.required, Validators.min(0), Validators.max(100)])
    });
  }

  // Getters for easy template access
  get rollNo() { return this.studentForm.get('rollNo'); }
  get fullName() { return this.studentForm.get('fullName'); }
  get email() { return this.studentForm.get('email'); }
  get marks() { return this.studentForm.get('marks'); }

  onSubmit(): void {
    if (this.studentForm.valid) {
      this.submittedData = this.studentForm.value;
      console.log('Submitted Reactive Form:', this.submittedData);
    }
  }

  resetForm(): void {
    this.studentForm.reset({ rollNo: 101, marks: 0 });
    this.submittedData = null;
  }
}
