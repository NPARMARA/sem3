import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  template: `
    <style>
      .login-box {
        width: 300px;
        margin: 60px auto;
        padding: 20px;
        border: 2px solid #ccc;
        
      }
      .input-field {
        width: 100%;
        padding: 6px;
        margin-top: 5px;
        margin-bottom: 15px;
        box-sizing: border-box;
      }
      .btn {
        width: 100%;
        padding: 8px;
        background-color: #007bff;
        color: white;
        border: none;
        cursor: pointer;
      }
    </style>

    <div class="login-box">
      <h2>Login Form</h2>
      
      <label>Username:</label>
      <input class="input-field" [(ngModel)]="username" placeholder="Enter username" />

      <label>Password:</label>
      <input class="input-field" [(ngModel)]="password" type="password" placeholder="Enter password" />

      <button class="btn" (click)="login()">Login</button>
      
      <p style="font-size: 13px; color: #666; text-align: center; margin-top: 10px;">
        Use: <b>admin</b> / <b>123</b>
      </p>
    </div>
  `
})
export class LoginComponent implements OnInit {
  username = '';
  password = '';

  constructor(private router: Router) {}

  ngOnInit() {
  
    const auth = localStorage.getItem('isLoggedIn');
    if (auth) {
      this.router.navigate(['/home']);
    }
  }

  login() {
    if (this.username === 'admin' && this.password === '123') {
      localStorage.setItem('isLoggedIn', 'true'); 
      this.router.navigate(['/home']);
    } else {
      alert('Invalid credentials! (use admin / 123)');
    }
  }
}