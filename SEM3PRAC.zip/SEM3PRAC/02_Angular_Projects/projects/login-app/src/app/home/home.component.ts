import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  template: `
    <style>
      .home-box {
        width: 350px;
        margin: 60px auto;
        padding: 20px;
        border: 2px solid #ccc;
        font-family: Arial, sans-serif;
        text-align: center;
      }
      .title {
        color: #28a745;
      }
      .logout-btn {
        padding: 8px 16px;
        background-color: #dc3545;
        color: white;
        border: none;
        cursor: pointer;
        font-size: 14px;
      }
    </style>

    <div class="home-box">
      <h2 class="title">Welcome to Homepage!</h2>
      <p>You have successfully logged in.</p>
      <button class="logout-btn" (click)="logout()">Logout</button>
    </div>
  `
})
export class HomeComponent implements OnInit {
  constructor(private router: Router) {}

  ngOnInit() {
    const auth = localStorage.getItem('isLoggedIn');
    if (!auth) {
      alert('Access Denied! Please login first.');
      this.router.navigate(['/']);
    }
  }

  logout() {
    localStorage.removeItem('isLoggedIn'); 
    this.router.navigate(['/']);
  }
}