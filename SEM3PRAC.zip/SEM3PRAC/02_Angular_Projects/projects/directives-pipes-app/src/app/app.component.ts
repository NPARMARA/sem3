import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { GradePipe } from './grade.pipe';

interface Student {
  id: number;
  name: string;
  marks: number;
  examDate: Date;
  feesPaid: number;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule, GradePipe],
  template: `
    <div class="container">
      <header class="header">
        <h2>Angular Directives & Pipes Master Demo</h2>
        <p>Demonstrating Structural Directives (*ngIf, *ngFor), Attribute Directives (ngClass, ngStyle) and Built-in/Custom Pipes</p>
      </header>

      <!-- CONTROL PANEL -->
      <div class="panel">
        <label>
          <input type="checkbox" [(ngModel)]="showDetails">
          Show Detailed Student Performance Cards (<code>*ngIf</code>)
        </label>
      </div>

      <!-- DIRECTIVES DEMO TABLE -->
      <section class="card">
        <h3>1. Directives Demonstration (*ngFor, *ngIf, [ngClass], [ngStyle])</h3>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>Student Name</th>
              <th>Marks</th>
              <th>Custom Pipe (Grade)</th>
              <th>Status (ngClass)</th>
            </tr>
          </thead>
          <tbody>
            <!-- *ngFor Structural Directive -->
            <tr *ngFor="let student of students; let i = index">
              <td>#{{ student.id }}</td>
              <td>{{ student.name }}</td>
              <td>
                <!-- [ngStyle] Attribute Directive -->
                <span [ngStyle]="{ 'color': student.marks >= 50 ? '#2e7d32' : '#c62828', 'font-weight': 'bold' }">
                  {{ student.marks }}
                </span>
              </td>
              <td>
                <!-- Custom Pipe: grade -->
                <span class="grade-pill">{{ student.marks | grade }}</span>
              </td>
              <td>
                <!-- [ngClass] Attribute Directive -->
                <span [ngClass]="student.marks >= 50 ? 'badge-pass' : 'badge-fail'">
                  {{ student.marks >= 50 ? 'PASSED' : 'FAILED' }}
                </span>
              </td>
            </tr>
          </tbody>
        </table>
      </section>

      <!-- PIPES DEMO SECTION -->
      <section class="card" *ngIf="showDetails">
        <h3>2. Angular Built-in Pipes Transformation</h3>
        <p>Original String: <code>{{ sampleText }}</code></p>
        <ul class="pipes-list">
          <li><strong>Uppercase Pipe:</strong> {{ sampleText | uppercase }}</li>
          <li><strong>Lowercase Pipe:</strong> {{ sampleText | lowercase }}</li>
          <li><strong>Date Pipe (fullDate):</strong> {{ today | date:'fullDate' }}</li>
          <li><strong>Date Pipe (shortTime):</strong> {{ today | date:'shortTime' }}</li>
          <li><strong>Currency Pipe (INR):</strong> {{ 25000 | currency:'INR':'symbol' }}</li>
          <li><strong>Percent Pipe:</strong> {{ 0.885 | percent:'1.1-2' }}</li>
          <li><strong>JSON Pipe (First Student):</strong>
            <pre>{{ students[0] | json }}</pre>
          </li>
        </ul>
      </section>
    </div>
  `,
  styles: [`
    .container { max-width: 850px; margin: 0 auto; }
    .header { background: #283593; color: white; padding: 20px 25px; border-radius: 8px 8px 0 0; }
    .header h2 { margin: 0; }
    .header p { margin: 5px 0 0 0; opacity: 0.9; font-size: 14px; }
    .panel { background: #e8eaf6; padding: 12px 20px; border-bottom: 1px solid #c5cae9; font-weight: 500; }
    .card { background: white; padding: 25px; border-radius: 0 0 8px 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.06); margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; margin-top: 15px; }
    th, td { padding: 12px; text-align: left; border-bottom: 1px solid #eee; }
    th { background: #f5f5f5; color: #333; font-weight: 600; }
    .badge-pass { background: #e8f5e9; color: #2e7d32; padding: 4px 10px; border-radius: 12px; font-weight: bold; font-size: 12px; }
    .badge-fail { background: #ffebee; color: #c62828; padding: 4px 10px; border-radius: 12px; font-weight: bold; font-size: 12px; }
    .grade-pill { background: #ede7f6; color: #512da8; padding: 3px 8px; border-radius: 4px; font-size: 13px; font-weight: 600; }
    .pipes-list { line-height: 1.8; }
    pre { background: #263238; color: #80cbc4; padding: 12px; border-radius: 6px; font-size: 13px; overflow-x: auto; }
  `]
})
export class AppComponent {
  showDetails = true;
  sampleText = 'Angular Framework Saurashtra University';
  today = new Date();

  students: Student[] = [
    { id: 101, name: 'Rahul Sharma', marks: 88, examDate: new Date(), feesPaid: 15000 },
    { id: 102, name: 'Priya Patel', marks: 74, examDate: new Date(), feesPaid: 15000 },
    { id: 103, name: 'Amit Mehta', marks: 35, examDate: new Date(), feesPaid: 12000 },
    { id: 104, name: 'Sneha Dave', marks: 95, examDate: new Date(), feesPaid: 15000 }
  ];
}
