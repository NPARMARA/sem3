import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'grade',
  standalone: true
})
export class GradePipe implements PipeTransform {
  transform(marks: number): string {
    if (marks >= 80) return 'Distinction (A+)';
    if (marks >= 70) return 'First Class (A)';
    if (marks >= 60) return 'Higher Second Class (B+)';
    if (marks >= 50) return 'Second Class (B)';
    if (marks >= 40) return 'Pass Class (C)';
    return 'Fail (F)';
  }
}
