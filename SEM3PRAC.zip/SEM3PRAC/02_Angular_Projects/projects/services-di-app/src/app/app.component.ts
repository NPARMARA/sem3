import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { StudentService, StudentRecord } from './student.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="card">
      <header class="header">
        <h2>Angular Services & Dependency Injection (DI)</h2>
        <p>Demonstrating &#64;Injectable service pattern, constructor-based Dependency Injection, and Observable data streams.</p>
      </header>

      <section class="content">
        <!-- ADD STUDENT BOX -->
        <div class="form-container">
          <h4>Register Student via Injected Service:</h4>
          <div class="form-row">
            <input type="number" [(ngModel)]="newStudent.rollNo" placeholder="Roll No" class="input" style="width: 120px;" />
            <input type="text" [(ngModel)]="newStudent.name" placeholder="Student Name" class="input" style="flex: 1;" />
            <button (click)="submitStudent()" class="btn btn-success">+ Add via Service</button>
          </div>
        </div>

        <!-- LIST DISPLAY -->
        <h4>Active Students (Provided by Singleton StudentService):</h4>
        <div *ngIf="students.length === 0" class="empty">No student records available.</div>
        <ul class="list">
          <li *ngFor="let s of students" class="list-item">
            <div>
              <strong>#{{ s.rollNo }}</strong> - {{ s.name }}
              <span class="badge">{{ s.course }} (Sem {{ s.semester }})</span>
            </div>
            <button (click)="removeStudent(s.rollNo)" class="btn btn-danger">Delete</button>
          </li>
        </ul>

        <div class="info-box">
          <strong>Why Dependency Injection?</strong>
          <p>The component does not instantiate <code>new StudentService()</code> itself. Instead, the Angular Injector automatically supplies the shared singleton instance via the constructor, promoting loose coupling, testability, and code reusability.</p>
        </div>
      </section>
    </div>
  `,
  styles: [`
    .card { max-width: 750px; margin: 0 auto; background: white; border-radius: 8px; box-shadow: 0 4px 16px rgba(0,0,0,0.08); overflow: hidden; }
    .header { background: #00897b; color: white; padding: 25px; }
    .header h2 { margin: 0; }
    .header p { margin: 6px 0 0 0; opacity: 0.9; }
    .content { padding: 25px; }
    .form-container { background: #e0f2f1; padding: 15px; border-radius: 6px; margin-bottom: 25px; }
    .form-container h4 { margin-top: 0; color: #00695c; }
    .form-row { display: flex; gap: 10px; }
    .input { padding: 8px 12px; border: 1px solid #b2dfdb; border-radius: 4px; font-size: 14px; }
    .btn { padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer; font-weight: 600; font-size: 13px; }
    .btn-success { background: #00897b; color: white; }
    .btn-danger { background: #e53935; color: white; }
    .list { list-style: none; padding: 0; margin: 15px 0; }
    .list-item { display: flex; justify-content: space-between; align-items: center; padding: 12px 15px; border-bottom: 1px solid #eee; background: #fafafa; margin-bottom: 8px; border-radius: 4px; }
    .badge { background: #b2dfdb; color: #004d40; padding: 2px 8px; border-radius: 12px; font-size: 12px; margin-left: 10px; }
    .info-box { background: #fff8e1; border-left: 4px solid #ffb300; padding: 12px 16px; margin-top: 25px; font-size: 14px; }
    .empty { color: #888; font-style: italic; margin: 15px 0; }
  `]
})
export class AppComponent implements OnInit {
  students: StudentRecord[] = [];
  newStudent: StudentRecord = { rollNo: 104, name: '', course: 'M.Sc. (IT & CA)', semester: 3 };

  // DEPENDENCY INJECTION via Constructor
  constructor(private studentService: StudentService) {}

  ngOnInit(): void {
    this.refreshStudents();
  }

  refreshStudents(): void {
    this.studentService.getStudents().subscribe((data) => {
      this.students = data;
    });
  }

  submitStudent(): void {
    if (!this.newStudent.name.trim()) {
      alert('Please enter a student name.');
      return;
    }
    this.studentService.addStudent({ ...this.newStudent }).subscribe(() => {
      this.refreshStudents();
      this.newStudent.rollNo++;
      this.newStudent.name = '';
    });
  }

  removeStudent(rollNo: number): void {
    this.studentService.deleteStudent(rollNo).subscribe(() => {
      this.refreshStudents();
    });
  }
}
