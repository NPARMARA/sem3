import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

export interface StudentRecord {
  rollNo: number;
  name: string;
  course: string;
  semester: number;
}

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  private students: StudentRecord[] = [
    { rollNo: 101, name: 'Rahul Sharma', course: 'M.Sc. (IT & CA)', semester: 3 },
    { rollNo: 102, name: 'Pooja Varma', course: 'M.Sc. (IT & CA)', semester: 3 },
    { rollNo: 103, name: 'Kishan Rathod', course: 'M.Sc. (IT & CA)', semester: 3 }
  ];

  constructor() {
    console.log('[StudentService] Instance initialized via Dependency Injection.');
  }

  // Returns list of students wrapped as an Observable (simulates HTTP GET)
  getStudents(): Observable<StudentRecord[]> {
    return of([...this.students]);
  }

  addStudent(student: StudentRecord): Observable<boolean> {
    this.students.push(student);
    return of(true);
  }

  deleteStudent(rollNo: number): Observable<boolean> {
    this.students = this.students.filter(s => s.rollNo !== rollNo);
    return of(true);
  }
}
