import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="card">
      <div class="header">
        <h1>Angular Component & Data Binding Mastery</h1>
        <p>Covers Topics 1, 2, 3 & 4 (Single Page Application, Component Anatomy, 4 Types of Data Binding)</p>
      </div>

      <!-- 1. STRING INTERPOLATION -->
      <section class="section">
        <h3>1. String Interpolation <code>{{ '{{ expression }}' }}</code></h3>
        <p>One-way binding from TypeScript component class to HTML template view:</p>
        <div class="demo-box">
          <p><strong>Course Title:</strong> {{ courseTitle }}</p>
          <p><strong>Department:</strong> {{ department }}</p>
          <p><strong>Expression Evaluation:</strong> 15 + 25 = {{ 15 + 25 }}</p>
          <p><strong>Uppercase Method Call:</strong> {{ getFormattedCourse() }}</p>
        </div>
      </section>

      <!-- 2. PROPERTY BINDING -->
      <section class="section">
        <h3>2. Property Binding <code>[property]="expression"</code></h3>
        <p>Binding dynamic data from component to an HTML element's DOM property:</p>
        <div class="demo-box">
          <input [value]="defaultRollNo" [disabled]="isInputDisabled" class="form-control" />
          <button (click)="toggleDisable()" class="btn btn-secondary" style="margin-top: 10px;">
            {{ isInputDisabled ? 'Enable Input Property' : 'Disable Input Property' }}
          </button>
          <p class="hint">Input disabled state: <strong>{{ isInputDisabled }}</strong></p>
        </div>
      </section>

      <!-- 3. EVENT BINDING -->
      <section class="section">
        <h3>3. Event Binding <code>(event)="handlerMethod()"</code></h3>
        <p>Capturing user actions from template to trigger TypeScript logic:</p>
        <div class="demo-box">
          <p>Current Counter Value: <span class="badge">{{ clickCounter }}</span></p>
          <button (click)="incrementCounter()" class="btn btn-primary">+ Increment Counter</button>
          <button (click)="resetCounter()" class="btn btn-danger" style="margin-left: 8px;">Reset</button>
        </div>
      </section>

      <!-- 4. TWO-WAY DATA BINDING -->
      <section class="section">
        <h3>4. Two-Way Data Binding <code>[(ngModel)]="variable"</code></h3>
        <p>Simultaneous bidirectional synchronization between input element and class property:</p>
        <div class="demo-box">
          <label><strong>Type Student Name:</strong></label>
          <input type="text" [(ngModel)]="studentName" class="form-control" placeholder="Enter student name..." />
          <div style="margin-top: 10px; padding: 10px; background: #e8f5e9; border-radius: 4px;">
            Live Synchronized Output: <strong>{{ studentName || '(Waiting for input...)' }}</strong>
          </div>
        </div>
      </section>
    </div>
  `,
  styles: [`
    .card {
      max-width: 800px;
      margin: 0 auto;
      background: #ffffff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.08);
    }
    .header {
      border-bottom: 2px solid #e0e0e0;
      padding-bottom: 15px;
      margin-bottom: 25px;
    }
    .header h1 { color: #dd0031; margin: 0; font-size: 26px; }
    .header p { color: #666; margin-top: 5px; }
    .section {
      margin-bottom: 25px;
      padding: 15px;
      background: #fafafa;
      border-left: 4px solid #dd0031;
      border-radius: 4px;
    }
    .section h3 { margin-top: 0; color: #1976d2; }
    code { background: #eef2f5; padding: 2px 6px; border-radius: 4px; color: #c2185b; font-family: monospace; }
    .demo-box { background: white; padding: 15px; border: 1px solid #e0e0e0; border-radius: 6px; margin-top: 10px; }
    .form-control { width: 100%; max-width: 350px; padding: 8px 12px; border: 1px solid #ccc; border-radius: 4px; display: block; }
    .btn { padding: 8px 16px; border: none; border-radius: 4px; cursor: pointer; font-weight: 600; }
    .btn-primary { background: #1976d2; color: white; }
    .btn-secondary { background: #607d8b; color: white; }
    .btn-danger { background: #d32f2f; color: white; }
    .badge { font-size: 18px; font-weight: bold; color: #1976d2; background: #e3f2fd; padding: 2px 10px; border-radius: 12px; }
    .hint { font-size: 13px; color: #777; margin-top: 5px; }
  `]
})
export class AppComponent {
  // Class properties (Model)
  courseTitle = 'CS-15: Web Development Using Angular Framework';
  department = 'Department of Computer Science - Saurashtra University';
  defaultRollNo = 'MSC-2026-101';
  isInputDisabled = true;
  clickCounter = 0;
  studentName = 'Rahul Sharma';

  getFormattedCourse(): string {
    return this.courseTitle.toUpperCase();
  }

  toggleDisable(): void {
    this.isInputDisabled = !this.isInputDisabled;
  }

  incrementCounter(): void {
    this.clickCounter++;
  }

  resetCounter(): void {
    this.clickCounter = 0;
  }
}
