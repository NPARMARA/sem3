import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

export interface Employee {
  eno: number;
  ename: string;
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <style>
      .container {
        max-width: 650px;
        margin: 40px auto;
        padding: 25px;
        border: 2px solid #ccc;
        background-color: #fcfcfc;
      }
      
      .form-box {
        margin-bottom: 25px;
        padding: 20px;
        border: 1px solid #ddd;
      }
      .form-group {
        margin-bottom: 12px;
      }
      
      .input-field {
        width: 100%;
        padding: 8px;
        box-sizing: border-box;
        border: 1px solid #ccc;
      }
      .btn {
        padding: 8px 16px;
        color: white;
        border: none;
        cursor: pointer;
        font-weight: bold;
        margin-right: 6px;
      }
      .btn-primary { background-color: #007bff; }
      .btn-secondary { background-color: #6c757d; }
      .btn-warning { background-color: #ffc107; color: black; font-weight: normal; padding: 4px 10px; }
      .btn-danger { background-color: #dc3545; font-weight: normal; padding: 4px 10px; }
      
      table {
        width: 100%;
        border-collapse: collapse;
        text-align: left;
      }
      th, td {
        border: 1px solid #ccc;
        padding: 10px;
      }
      
      .text-center {
        text-align: center;
      }
    </style>

    <div class="container">
      <h2>Employee CRUD Operations</h2>

      <form (ngSubmit)="saveEmployee()" class="form-box">
        <div class="form-group">
          <label>Employee No (ENO):</label>
          <input
            type="number"
            class="input-field"
            [(ngModel)]="currentEmp.eno"
            name="eno"
            [disabled]="isEdit"
            placeholder="Enter ENO"
            required
          />
        </div>

        <div class="form-group">
          <label>Employee Name:</label>
          <input
            type="text"
            class="input-field"
            [(ngModel)]="currentEmp.ename"
            name="ename"
            placeholder="Enter Employee Name"
            required
          />
        </div>

        <button type="submit" class="btn btn-primary">
          {{ isEdit ? 'Update' : 'Add' }}
        </button>

        <button *ngIf="isEdit" type="button" (click)="resetForm()" class="btn btn-secondary">
          Cancel
        </button>
      </form>

      <table>
        <thead>
          <tr>
            <th style="width: 25%;">ENO</th>
            <th>Employee Name</th>
            <th style="width: 28%;" class="text-center">Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let emp of employees">
            <td><b>{{ emp.eno }}</b></td>
            <td>{{ emp.ename }}</td>
            <td class="text-center">
              <button (click)="editEmployee(emp)" class="btn btn-warning">Edit</button>
              <button (click)="deleteEmployee(emp.eno)" class="btn btn-danger">Delete</button>
            </td>
          </tr>
          <tr *ngIf="employees.length === 0">
            <td colspan="3" class="text-center" style="color: #777;">No employee records found.</td>
          </tr>
        </tbody>
      </table>
    </div>
  `
})
export class AppComponent implements OnInit {
  employees: Employee[] = [];
  currentEmp: Employee = { eno: 0, ename: '' };
  isEdit = false;

  ngOnInit() {
    this.loadEmployees();
  }

  loadEmployees() {
    const data = localStorage.getItem('crud_employees');
    if (data) {
      this.employees = JSON.parse(data);
    } else {
      this.employees = [
        { eno: 1, ename: 'John Doe' },
        { eno: 2, ename: 'Alice Smith' }
      ];
      this.saveToStorage();
    }
  }

  saveToStorage() {
    localStorage.setItem('crud_employees', JSON.stringify(this.employees));
  }

  saveEmployee() {
    if (!this.currentEmp.eno || !this.currentEmp.ename.trim()) {
      alert('Please enter both ENO and Employee Name.');
      return;
    }

    if (this.isEdit) {
      const index = this.employees.findIndex(e => e.eno === this.currentEmp.eno);
      if (index !== -1) {
        this.employees[index].ename = this.currentEmp.ename;
      }
    } else {
      if (this.employees.some(e => e.eno === this.currentEmp.eno)) {
        alert('Employee with this ENO already exists!');
        return;
      }
      this.employees.push({ ...this.currentEmp });
    }

    this.saveToStorage();
    this.resetForm();
  }

  editEmployee(emp: Employee) {
    this.currentEmp = { ...emp };
    this.isEdit = true;
  }

  deleteEmployee(eno: number) {
    if (confirm(`Are you sure you want to delete employee #${eno}?`)) {
      this.employees = this.employees.filter(e => e.eno !== eno);
      this.saveToStorage();
      if (this.isEdit && this.currentEmp.eno === eno) {
        this.resetForm();
      }
    }
  }

  resetForm() {
    this.currentEmp = { eno: 0, ename: '' };
    this.isEdit = false;
  }
}