# 🎓 M.Sc. (IT & CA) Semester 3: Master Practical & Definition Projects Guide
### Saurashtra University — Examination Practical Blueprint
**Subjects Covered:**
- **CS-14 & CS-17:** Node.js & Express (Part 1)
- **CS-15 & CS-17:** Web Development Using Angular Framework (Part 2)
- **CS-13 & CS-16:** Flutter App Development (Part 3)

---

## 📁 Complete Workspace Architecture

```
S:\NYN\BCA\MSCIT\SEM3PRAC\
│
├── 🟢 01_NodeJS_Express/
│   ├── 01_nodejs_runtime_basics/      → Topic 1: Node.js Runtime & V8 Engine
│   ├── 02_repl_interactive/          → Topic 2: REPL Shell, Commands, '_' Variable
│   ├── 03_buffer_binary_data/         → Topic 3: Buffers, Raw Binary Streams, Encodings
│   ├── 04_modules_system/             → Topic 4: Core, Local, & Third-Party Modules
│   ├── 05_npm_package_manager/        → Topic 5: NPM, package.json, SemVer (^, ~)
│   ├── 06_event_driven_nonblocking/   → Topic 6: Non-Blocking I/O & Event Loop Priority
│   ├── 07_event_emitter/              → Topic 7: EventEmitter, .on(), .once(), .emit()
│   ├── 08_express_web_server/         → Topic 8: Express Server, REST API, Route Params
│   ├── 09_express_middleware/         → Topic 9: Application, Built-in, Route Guard & Error Middleware
│   ├── 10_ejs_template_engine/        → Topic 10: EJS Server-Side Rendering & Partials
│   ├── package.json
│   └── README.md
│
├── 🔵 02_Angular_Projects/
│   ├── projects/
│   │   ├── databinding-app/           → Topics 1-4: SPA, Component, 4 Data Bindings
│   │   ├── directives-pipes-app/      → Topics 5-6: Directives (*ngIf, *ngFor) & Built-in/Custom Pipes
│   │   ├── services-di-app/           → Topics 7-8: @Injectable Services & Dependency Injection
│   │   ├── routing-app/               → Topic 9: Angular Router, RouterOutlet, Links
│   │   ├── reactive-forms-app/        → Topic 10: Reactive Forms, FormGroup, Validators
│   │   ├── login-app/                 → Authentication Practical (Login, Storage, Guard)
│   │   └── crud-app/                  → Master Employee CRUD with Persistent Storage
│   ├── angular.json
│   ├── package.json
│   └── README.md
│
├── 🟠 03_Flutter_Dart/
│   ├── 01_dart_fundamentals/          → Topic 2: Dart Syntax, Null Safety, OOP, Async
│   ├── 02_flutter_widgets_app/        → Topics 1, 3, 4, 5: UI Widgets, Stateless vs Stateful
│   ├── 03_navigation_routes_app/      → Topics 6-7: Hot Reload & Navigator Route Stack
│   ├── 04_state_management_app/       → Topic 8: ChangeNotifier & InheritedNotifier (Provider)
│   ├── 05_rest_api_app/               → Topic 9: REST HTTP, jsonDecode, FutureBuilder
│   ├── 06_sqlite_database_app/        → Topic 10: SQLite (sqflite) Local Relational CRUD
│   └── README.md
│
└── MASTER_EXAM_PRACTICAL_GUIDE.md     → This Guide
```

---

## 🟢 Part 1: Node.js & Express Practical Reference

| No | Syllabus Definition | Project Folder | Command to Run |
| :---: | :--- | :--- | :--- |
| **1** | **Node.js**: Cross-platform JavaScript runtime on Chrome V8 engine. | `01_NodeJS_Express/01_nodejs_runtime_basics` | `node 01_nodejs_runtime_basics/runtime_basics.js` |
| **2** | **REPL**: Read-Eval-Print Loop interactive execution shell (`_` stores last result). | `01_NodeJS_Express/02_repl_interactive` | `node 02_repl_interactive/custom_repl.js` |
| **3** | **Buffer**: Temporary raw binary storage handling network/file streams. | `01_NodeJS_Express/03_buffer_binary_data` | `node 03_buffer_binary_data/buffer_demo.js` |
| **4** | **Module**: Reusable code units: Core (`path`, `fs`), Local (`./math`), 3rd-party. | `01_NodeJS_Express/04_modules_system` | `node 04_modules_system/modules_demo.js` |
| **5** | **NPM**: Package manager managing dependencies, versions, and scripts. | `01_NodeJS_Express/05_npm_package_manager` | `node 05_npm_package_manager/npm_demo.js` |
| **6** | **Non-Blocking I/O**: Asynchronous event loop delegating operations to libuv. | `01_NodeJS_Express/06_event_driven_nonblocking` | `node 06_event_driven_nonblocking/event_loop_demo.js` |
| **7** | **EventEmitter**: Core class in `events` module emitting named events to listeners. | `01_NodeJS_Express/07_event_emitter` | `node 07_event_emitter/event_emitter_demo.js` |
| **8** | **Express.js**: Minimal web framework for routing, parameters, and responses. | `01_NodeJS_Express/08_express_web_server` | `node 08_express_web_server/server.js` |
| **9** | **Middleware**: Functions accessing `req`, `res`, `next` in request cycle. | `01_NodeJS_Express/09_express_middleware` | `node 09_express_middleware/middleware_server.js` |
| **10**| **Template Engine (EJS)**: Generates dynamic HTML server-side using `<%= %>`. | `01_NodeJS_Express/10_ejs_template_engine` | `node 10_ejs_template_engine/ejs_server.js` |

---

## 🔵 Part 2: Angular Practical Reference

| No | Syllabus Definition | Project Folder | Command to Run |
| :---: | :--- | :--- | :--- |
| **1** | **Angular**: TypeScript SPA framework developed by Google. | `02_Angular_Projects/projects/databinding-app` | `npm run start:databinding` |
| **2** | **Single Page App (SPA)**: Loads single page and swaps views without reloading. | `02_Angular_Projects/projects/databinding-app` | `npm run start:databinding` |
| **3** | **Component**: Basic building block (TS Class + HTML Template + CSS). | `02_Angular_Projects/projects/databinding-app` | `npm run start:databinding` |
| **4** | **Data Binding**: Interpolation `{{}}`, `[property]`, `(event)`, `[(ngModel)]`. | `02_Angular_Projects/projects/databinding-app` | `npm run start:databinding` |
| **5** | **Directive**: Extends DOM behavior: Structural (`*ngIf`, `*ngFor`), Attribute. | `02_Angular_Projects/projects/directives-pipes-app` | `npm run start:directives-pipes` |
| **6** | **Pipe**: Transforms template values (`uppercase`, `date`, `currency`, custom). | `02_Angular_Projects/projects/directives-pipes-app` | `npm run start:directives-pipes` |
| **7** | **Service**: Shared business logic & HTTP client data layer. | `02_Angular_Projects/projects/services-di-app` | `npm run start:services-di` |
| **8** | **Dependency Injection**: Design pattern injecting dependencies via constructor. | `02_Angular_Projects/projects/services-di-app` | `npm run start:services-di` |
| **9** | **Routing**: Client-side navigation between views based on URL paths. | `02_Angular_Projects/projects/routing-app` | `npm run start:routing` |
| **10**| **Reactive Forms**: Model-driven forms using `FormGroup`, `FormControl`, `Validators`. | `02_Angular_Projects/projects/reactive-forms-app` | `npm run start:reactive-forms` |

---

## 🟠 Part 3: Flutter & Dart Practical Reference

| No | Syllabus Definition | Project Folder | Command to Run |
| :---: | :--- | :--- | :--- |
| **1** | **Flutter**: Cross-platform native UI toolkit from single codebase. | `03_Flutter_Dart/02_flutter_widgets_app` | `flutter run -d chrome` |
| **2** | **Dart**: Client-optimized OOP language with sound null safety. | `03_Flutter_Dart/01_dart_fundamentals` | `dart run bin/main.dart` |
| **3** | **Widget**: Fundamental UI building block ("everything is a widget"). | `03_Flutter_Dart/02_flutter_widgets_app` | `flutter run -d chrome` |
| **4** | **StatelessWidget**: Immutable widget without mutable state. | `03_Flutter_Dart/02_flutter_widgets_app` | `flutter run -d chrome` |
| **5** | **StatefulWidget**: Tracks mutable state and redraws via `setState()`. | `03_Flutter_Dart/02_flutter_widgets_app` | `flutter run -d chrome` |
| **6** | **Hot Reload**: Injects source changes into Dart VM without state loss. | `03_Flutter_Dart/03_navigation_routes_app` | `flutter run -d chrome` |
| **7** | **Navigator**: Manages screen routes on a LIFO navigation stack. | `03_Flutter_Dart/03_navigation_routes_app` | `flutter run -d chrome` |
| **8** | **State Management**: Centralized data sharing (ChangeNotifier / Provider / BLoC). | `03_Flutter_Dart/04_state_management_app` | `flutter run -d chrome` |
| **9** | **REST API**: Asynchronous HTTP networking with `FutureBuilder` & `jsonDecode`. | `03_Flutter_Dart/05_rest_api_app` | `flutter run -d chrome` |
| **10**| **SQLite (`sqflite`)**: Local on-device relational database with CRUD. | `03_Flutter_Dart/06_sqlite_database_app` | `flutter run -d chrome` |

---

## 🎯 Important Practical Viva Questions & Tips

1. **What is the difference between `module.exports` and `exports` in Node.js?**
   - `module.exports` is the actual object that gets returned by `require()`. `exports` is simply a reference shortcut pointing to `module.exports`. If you assign `exports = function() {}`, the reference is broken!
2. **What is the difference between Property Binding and String Interpolation in Angular?**
   - Interpolation (`{{ value }}`) always evaluates to a string. Property binding (`[property]="value"`) allows passing non-string values like booleans (e.g. `[disabled]="true"`) and objects.
3. **What is the difference between `StatelessWidget` and `StatefulWidget` in Flutter?**
   - A `StatelessWidget` does not have mutable state and only overrides `build(BuildContext context)`. A `StatefulWidget` creates an associated `State` class that maintains mutable state and calls `setState()` to repaint.
